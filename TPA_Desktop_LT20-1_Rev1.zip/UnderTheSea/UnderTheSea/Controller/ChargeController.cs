﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class ChargeController
    {
        public static bool charge(int visitorId, int price, string information)
        {
            int employeeId = EmployeeSingleton.getEmployeeData().Id;
            DateTime date = DateTime.Now;

            VisitorData vd = VisitorDataRepository.checkVisitor(visitorId);
            if (vd == null || !vd.Status.Equals("Active"))
                return false;

            Charge c = ChargeFactory.create(employeeId, visitorId, price, information, date);
            return ChargeRepository.charge(c);
        }
    }
}
