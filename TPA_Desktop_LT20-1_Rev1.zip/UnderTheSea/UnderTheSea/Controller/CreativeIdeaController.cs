﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class CreativeIdeaController
    {
        public static List<CreativeIdea> getAllIdea()
        {
            return CreativeIdeaRepository.getAllIdea();
        }

        public static bool updateIdea(int id, string status, string note)
        {
            return CreativeIdeaRepository.updateIdea(id, status, note);
        }

        public static bool addIdea(string ideaType, string ideaName, string rideOrAttraction, string ideaDetail)
        {
            string status = "Waiting";
            DateTime date = DateTime.Now;

            CreativeIdea ci = CreativeIdeaFactory.create(ideaType, ideaName, rideOrAttraction, ideaDetail, status, date);
            return CreativeIdeaRepository.addIdea(ci);
        }
    }
}
