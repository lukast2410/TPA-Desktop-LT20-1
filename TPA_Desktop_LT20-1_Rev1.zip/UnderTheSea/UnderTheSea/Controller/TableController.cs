﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class TableController
    {
        public static List<Table> getAllTable()
        {
            return TableRepository.getAllTable();
        }

        public static bool changeTableStatus(int tableNumber)
        {
            Table tb = TableRepository.checkTable(tableNumber);
            if (tb == null)
                return false;

            string status = "Available";
            if (tb.Status.Equals("Available"))
                status = "Not Available";

            TableRepository.changeTableStatus(tableNumber, status);
            return true;
        }

        public static Table checkTable(int tableNumber)
        {
            return TableRepository.checkTable(tableNumber);
        }
    }
}
