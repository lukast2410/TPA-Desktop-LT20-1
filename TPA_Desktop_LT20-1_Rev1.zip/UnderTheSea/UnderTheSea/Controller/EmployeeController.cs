﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class EmployeeController
    {
        public static Employee login(string email, string password)
        {
            return EmployeeSingleton.getEmployee(email, password);
        }

        public static List<Employee> getAllEmployeeData()
        {
            return EmployeeRepository.getAllEmployeeData();
        }

        public static bool addEmployee(string name, string email, string password, DateTime DOB,
            string gender, string phone, int roleId, string status, int salary)
        {
            if (EmployeeRepository.checkEmployee(email) != null)
                return false;

            Employee emp = EmployeeFactory.create(name, email, password, DOB, gender, phone, roleId, status, salary);
            EmployeeRepository.addEmployee(emp);
            return true;
        }

        public static bool updateEmployee(int id, string name, string email, string password, DateTime DOB,
            string gender, string phone, int roleId, string status, int salary)
        {
            Employee check = EmployeeRepository.checkEmployee(email);
            if (check != null && check.Id != id)
                return false;

            EmployeeRepository.updateEmployee(id, name, email, password, DOB, gender, phone, roleId, status, salary);
            return true;
        }
    }
}
