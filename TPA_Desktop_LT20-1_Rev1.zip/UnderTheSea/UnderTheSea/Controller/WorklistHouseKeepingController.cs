﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class WorklistHouseKeepingController
    {
        public static List<WorklistHouseKeeping> getAllWorklistHouseKeeping()
        {
            return WorklistHouseKeepingRepository.getAllWorklistHouseKeeping();
        }

        public static bool addWorklistHouseKeeping(int roomNumber, string detail, DateTime date)
        {
            Room r = RoomRepository.getRoom(roomNumber);
            int employeeId = EmployeeSingleton.getEmployeeData().Id;

            if (r == null)
                return false;

            WorklistHouseKeeping whk = WorklistHouseKeepingFactory.create(employeeId, roomNumber, detail, date);
            return WorklistHouseKeepingRepository.addWorklistHouseKeeping(whk);
        }
    }
}
