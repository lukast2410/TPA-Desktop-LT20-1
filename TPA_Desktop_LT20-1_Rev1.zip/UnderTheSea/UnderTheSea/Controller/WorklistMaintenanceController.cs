﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class WorklistMaintenanceController
    {
        public static List<WorklistMaintenance> getAllWorklistMaintenance()
        {
            return WorklistMaintenanceRepository.getAllWorklistMaintenance();
        }

        public static bool addWorklistMaintenance(int rideAndAttractionId, string information, string status)
        {
            RideAndAttraction raa = RideAndAttractionRepository.getOneRideAndAttraction(rideAndAttractionId);

            if (raa == null)
                return false;

            DateTime date = DateTime.Now;

            WorklistMaintenance wm = WorklistMaintenanceFactory.create(rideAndAttractionId, information, date, status);
            return WorklistMaintenanceRepository.addWorklistMaintenance(wm);
        }

        public static bool updateWorklistMaintenance(int id, int rideAndAttractionId, string information, string status)
        {
            WorklistMaintenance wm = WorklistMaintenanceRepository.checkWorklistMaintenance(id);

            if (wm == null || wm.Status.Equals("Removed"))
                return false;

            if (wm.RideAndAttractionId != rideAndAttractionId)
                RideAndAttractionRepository.updateRideAndAttractionStatus(wm.RideAndAttractionId, "Active");

            string statusRideAndAttraction = "Active";

            if (status.Equals("In Progress"))
                statusRideAndAttraction = "Under Maintenance";

            RideAndAttractionRepository.updateRideAndAttractionStatus(rideAndAttractionId, statusRideAndAttraction);
            return WorklistMaintenanceRepository.updateWorklistMaintenance(id, rideAndAttractionId, information, status);
        }

        public static bool removeWorklistMaintenance(int id)
        {
            WorklistMaintenance wm = WorklistMaintenanceRepository.checkWorklistMaintenance(id);

            if (wm == null || wm.Status.Equals("Removed"))
                return false;

            RideAndAttractionRepository.updateRideAndAttractionStatus(wm.RideAndAttractionId, "Active");
            return WorklistMaintenanceRepository.removeWorklistMaintenance(id);
        }
    }
}
