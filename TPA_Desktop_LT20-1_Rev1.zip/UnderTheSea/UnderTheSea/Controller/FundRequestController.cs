﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class FundRequestController
    {
        public static bool requestFund(int totalAmount, string information)
        {
            int roleId = EmployeeSingleton.getEmployeeData().RoleId;
            DateTime date = DateTime.Now;

            FundRequest fr = FundRequestFactory.create(roleId, totalAmount, information, "Waiting", date);
            return FundRequestRepository.requestFund(fr);
        }

        public static List<FundRequest> getAllFundRequest()
        {
            return FundRequestRepository.getAllFundRequest();
        }

        public static bool updateFundRequestStatus(int id, string status)
        {
            return FundRequestRepository.updateFundRequestStatus(id, status);
        }
    }
}
