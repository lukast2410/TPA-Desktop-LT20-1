﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class InboxController
    {
        public static List<Inbox> getRoleInbox()
        {
            return InboxRepository.getRoleInbox(EmployeeSingleton.getEmployeeData().RoleId);
        }

        public static Inbox getOneInbox(int id)
        {
            Inbox ibx = InboxRepository.getOneInbox(id);

            if (ibx.ReceiverRoleId != EmployeeSingleton.getEmployeeData().RoleId)
                return null;

            return ibx;
        }

        public static bool sendMail(int receiverRoleId, string title, string content)
        {
            DateTime date = DateTime.Now;
            int senderRoleId = EmployeeSingleton.getEmployeeData().RoleId;

            Inbox ibx = InboxFactory.create(title, content, senderRoleId, receiverRoleId, date);
            return InboxRepository.sendMail(ibx);
        }
    }
}
