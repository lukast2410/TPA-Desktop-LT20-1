﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class PersonalRequestController
    {
        public static bool addPersonalRequest(string type, string reason)
        {
            string status = "Waiting";
            int employeeId = EmployeeSingleton.getEmployeeData().Id;
            DateTime date = DateTime.Now;
            string note = "";

            PersonalRequest pr = PersonalRequestFactory.create(employeeId, type, reason, status, date, note);
            return PersonalRequestRepository.addPersonalRequest(pr);
        }

        public static List<PersonalRequest> getMyPersonalRequest()
        {
            int employeeId = EmployeeSingleton.getEmployeeData().Id;

            return PersonalRequestRepository.getMyPersonalRequest(employeeId);
        }

        public static List<PersonalRequest> getLeavingPermitRequest()
        {
            string type = "Leaving Permit Request";

            return PersonalRequestRepository.getAllPersonalRequestByType(type);
        }

        public static List<PersonalRequest> getResignRequest()
        {
            string type = "Resign Request";

            return PersonalRequestRepository.getAllPersonalRequestByType(type);
        }

        public static bool updateLeavingPermitRequest(int id, string status, string note)
        {
            PersonalRequest pr = PersonalRequestRepository.checkPersonalRequest(id);

            if (pr == null || !pr.Type.Equals("Leaving Permit Request"))
                return false;

            PersonalRequestRepository.updatePersonalRequest(id, status, note);
            return true;
        }

        public static bool updateResignRequest(int id, string status, string note)
        {
            PersonalRequest pr = PersonalRequestRepository.checkPersonalRequest(id);

            if (pr == null || !pr.Type.Equals("Resign Request"))
                return false;

            PersonalRequestRepository.updatePersonalRequest(id, status, note);
            return true;
        }
    }
}
