﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class VisitorDataController
    {
        public static List<VisitorData> getAllVisitorData()
        {
            return VisitorDataRepository.getAllVisitorData();
        }

        public static bool addVisitorData(string name, string identityNumber, string phone, string email, DateTime dob, string gender, string status)
        {
            VisitorData vd = VisitorDataFactory.create(name, identityNumber, phone, email, dob, gender, status);
            return VisitorDataRepository.addVisitorData(vd);
        }

        public static bool updateVisitorData(int id, string name, string identityNumber, string phone, string email, DateTime dob, string gender, string status)
        {
            VisitorData vd = VisitorDataRepository.checkVisitor(id);

            if (vd == null || vd.Status.Equals("Removed"))
                return false;

            return VisitorDataRepository.updateVisitorData(id, name, identityNumber, phone, email, dob, gender, status);
        }

        public static bool removeVisitorData(int id)
        {
            return VisitorDataRepository.removeVisitorData(id);
        }
    }
}
