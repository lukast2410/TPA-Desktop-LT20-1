﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class RateAndFeedbackController
    {
        public static List<RateAndFeedback> getAllRateAndFeedback()
        {
            return RateAndFeedbackRepository.getAllRateAndFeedback();
        }

        public static bool addRateAndFeedback(int rate, string feedback)
        {
            DateTime date = DateTime.Now;

            RateAndFeedback raf = RateAndFeedbackFactory.create(rate, feedback, date);
            return RateAndFeedbackRepository.addRateAndFeedback(raf);
        }
    }
}
