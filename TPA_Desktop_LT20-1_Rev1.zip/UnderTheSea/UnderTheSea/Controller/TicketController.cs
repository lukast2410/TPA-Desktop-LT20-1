﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class TicketController
    {
        public static Ticket generateTicket()
        {
            DateTime date = DateTime.Today.AddDays(1);
            Ticket t = TicketFactory.create(date);
            TicketRepository.generateTicket(t);
            return t;
        }

        public static Ticket scanTicket(int code)
        {
            Ticket t = TicketRepository.getTicket(code);

            if (t == null)
                return null;

            DateTime date = DateTime.Today;
            if (t.ExpiredDate.Date.AddDays(-1) != date.Date)
                return null;

            return t;
        }
    }
}
