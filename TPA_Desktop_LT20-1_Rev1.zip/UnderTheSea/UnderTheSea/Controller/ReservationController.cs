﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class ReservationController
    {
        public static List<Reservation> getAllReservation()
        {
            return ReservationRepository.getAllReservation();
        }

        public static Reservation createReservation(int visitorId, int roomNumber, DateTime checkIn, int nights, string status)
        {
            VisitorData vd = VisitorDataRepository.checkVisitor(visitorId);
            Room r = RoomRepository.getRoom(roomNumber);

            if (vd == null || r == null || !vd.Status.Equals("Active"))
                return null;

            DateTime checkOut = checkIn.Date.AddDays(nights);
            int employeeId = EmployeeSingleton.getEmployeeData().Id;

            return ReservationFactory.create(employeeId, visitorId, roomNumber, checkIn, checkOut, status);
        }

        public static bool addReservation(Reservation reserv)
        {
            RoomRepository.updateRoomStatus(reserv.RoomNumber, "Booked");
            return ReservationRepository.addReservation(reserv);
        }

        public static bool updateReservation(int id, Reservation reserv)
        {
            Reservation check = ReservationRepository.getOneReservation(id);
            int employeeId = EmployeeSingleton.getEmployeeData().Id;

            if (check == null || check.Status.Equals("Removed"))
                return false;

            if (check.RoomNumber != reserv.RoomNumber)
                RoomRepository.updateRoomStatus(check.RoomNumber, "Available");

            int visitorId = (int)reserv.VisitorId;
            RoomRepository.updateRoomStatus(reserv.RoomNumber, "Booked");
            return ReservationRepository.updateReservation(id, employeeId, (int)reserv.VisitorId, reserv.RoomNumber, 
                (DateTime)reserv.CheckInDate, (DateTime)reserv.CheckOutDate, reserv.Status);
        }

        public static bool removeReservation(int id)
        {
            Reservation check = ReservationRepository.getOneReservation(id);
            int employeeId = EmployeeSingleton.getEmployeeData().Id;

            if (check == null || !check.Status.Equals("Booked"))
                return false;
            
            RoomRepository.updateRoomStatus(check.RoomNumber, "Available");
            return ReservationRepository.removeReservation(id);
        }

        public static bool checkIn(int id)
        {
            Reservation check = ReservationRepository.getOneReservation(id);

            if (check == null || !check.Status.Equals("Booked"))
                return false;

            RoomRepository.updateRoom(check.RoomNumber, (int)check.VisitorId, (DateTime)check.CheckOutDate, (DateTime)check.CheckInDate, "Not Available");
            ReservationRepository.updateReservationStatus(id, "Checked In");
            return true;
        }

        public static bool checkOut(int id)
        {
            Reservation check = ReservationRepository.getOneReservation(id);

            if (check == null || !check.Status.Equals("Checked In"))
                return false;

            RoomRepository.roomCheckOut(check.RoomNumber);
            ReservationRepository.updateReservationStatus(id, "Checked Out");
            return true;
        }
    }
}
