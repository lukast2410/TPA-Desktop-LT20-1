﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class OrderController
    {
        public static List<OrderDetail> getAllOrderDetail()
        {
            return OrderRepository.getAllOrderDetail();
        }

        public static bool updateOrderDetailStatus(int foodId, int orderId, string status)
        {
            return OrderRepository.updateOrderDetailStatus(foodId, orderId, status);
        }

        public static bool updateOrderDetail(int foodId, int orderId, string status, int quantity)
        {
            OrderDetail od = OrderRepository.checkOrderDetail(foodId, orderId);

            if(od == null){
                od = OrderDetailFactory.create(orderId, foodId, quantity, status);
                return OrderRepository.addOrderDetail(od);
            }

            return OrderRepository.updateOrderDetail(foodId, orderId, status, quantity);
        }

        public static Order createOrder(int tableNumber)
        {
            int employeeId = EmployeeSingleton.getEmployeeData().Id;
            DateTime date = DateTime.Now;

            Order od = OrderFactory.create(tableNumber, employeeId, date);
            OrderRepository.createOrder(od);
            return od;
        }

        public static bool addOrderDetail(int foodId, int orderId, int quantity)
        {
            string status = "Waiting";

            OrderDetail od = OrderDetailFactory.create(orderId, foodId, quantity, status);
            return OrderRepository.addOrderDetail(od);
        }
    }
}
