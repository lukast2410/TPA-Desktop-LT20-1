﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class RideAndAttractionController
    {
        public static List<RideAndAttraction> getAllRideAndAttraction()
        {
            return RideAndAttractionRepository.getAllRideAndAttraction();
        }

        public static List<RideAndAttraction> getAllRide()
        {
            return RideAndAttractionRepository.getAllRide();
        }

        public static bool addRideAndAttraction(string name, string detail, string status, string type)
        {
            RideAndAttraction raa = RideAndAttractionFactory.create(name, detail, status, type);
            return RideAndAttractionRepository.addRideAndAttraction(raa);
        }

        public static bool updateRideAndAttraction(int id, string name, string detail, string status, string type)
        {
            RideAndAttraction raa = RideAndAttractionRepository.getOneRideAndAttraction(id);

            if (raa == null || raa.Status.Equals("Removed"))
                return false;

            return RideAndAttractionRepository.updateRideAndAttraction(id, name, detail, status, type);
        }

        public static bool updateRideStatus(int id, string status)
        {
            RideAndAttraction raa = RideAndAttractionRepository.getOneRideAndAttraction(id);

            if (raa == null || raa.Status.Equals("Removed") || !raa.Type.Equals("Ride"))
                return false;

            RideAndAttractionRepository.updateRideAndAttractionStatus(id, status);
            return true;
        }

        public static bool removeRideAndAttraction(int id)
        {
            RideAndAttraction raa = RideAndAttractionRepository.getOneRideAndAttraction(id);

            if (raa == null || raa.Status.Equals("Removed"))
                return false;

            return RideAndAttractionRepository.removeRideAndAttraction(id);
        }
    }
}
