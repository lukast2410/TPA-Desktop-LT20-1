﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class PurchaseRequestController
    {
        public static bool requestPurchase(string detail, string information)
        {
            int roleId = EmployeeSingleton.getEmployeeData().RoleId;
            DateTime date = DateTime.Now;

            PurchaseRequest pr = PurchaseRequestFactory.create(roleId, detail, information, "Waiting", date);
            return PurchaseRequestRepository.requestPurchase(pr);
        }

        public static List<PurchaseRequest> getAllPurchaseRequest()
        {
            return PurchaseRequestRepository.getAllPurchaseRequest();
        }

        public static bool updatePurchaseRequestStatus(int id, string status)
        {
            return PurchaseRequestRepository.updatePurchaseRequestStatus(id, status);
        }
    }
}
