﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class TicketTransactionController
    {
        public static List<TicketTransaction> getAllTicketTransaction()
        {
            return TicketTransactionRepository.getAllTicketTransaction();
        }

        public static bool addTicketTransaction(int quantity)
        {
            DateTime date = DateTime.Now;
            int employeeId = EmployeeSingleton.getEmployeeData().Id;

            TicketTransaction transaction = TicketTransactionFactory.create(employeeId, date, quantity);
            return TicketTransactionRepository.addTicketTransaction(transaction);
        }
    }
}
