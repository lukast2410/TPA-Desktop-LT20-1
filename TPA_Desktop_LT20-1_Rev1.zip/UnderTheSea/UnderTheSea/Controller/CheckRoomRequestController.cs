﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class CheckRoomRequestController
    {
        public static List<CheckRoomRequest> getAllCheckRoomRequest()
        {
            return CheckRoomRequestRepository.getAllCheckRoomRequest();
        }

        public static bool requestCheckRoom(int roomNumber)
        {
            Room r = RoomRepository.getRoom(roomNumber);

            if (r == null)
                return false;

            string status = "Waiting";
            CheckRoomRequest crr = CheckRoomRequestFactory.create(roomNumber, status);
            CheckRoomRequestRepository.requestCheckRoom(crr);
            return true;
        }

        public static bool checkRoomDone(int id)
        {
            return CheckRoomRequestRepository.checkRoomDone(id);
        }
    }
}
