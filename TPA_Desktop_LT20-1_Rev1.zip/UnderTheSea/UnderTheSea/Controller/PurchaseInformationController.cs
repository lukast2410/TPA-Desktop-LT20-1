﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class PurchaseInformationController
    {
        public static List<PurchaseInformation> getAllPurchaseInformation()
        {
            return PurchaseInformationRepository.getAllPurchaseInformation();
        }

        public static bool addPurchaseInformation(string information)
        {
            int employeeId = EmployeeSingleton.getEmployeeData().Id;
            DateTime date = DateTime.Now;

            PurchaseInformation pi = PurchaseInformationFactory.create(employeeId, information, date);
            return PurchaseInformationRepository.addPurchaseInformation(pi);
        }
    }
}
