﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class WorkPerformanceController
    {
        public static List<WorkPerformance> getAllWorkPerformance()
        {
            return WorkPerformanceRepository.getAllWorkPerformance();
        }

        public static bool addWorkPerformance(int employeeId, string detail)
        {
            if (WorkPerformanceRepository.checkWorkPerformance(employeeId) != null)
                return false;

            WorkPerformance wp = WorkPerformanceFactory.create(employeeId, "Active", detail);
            WorkPerformanceRepository.addWorkPerformance(wp);
            return true;
        }

        public static bool updateWorkPerformance(int id, int employeeId, string detail)
        {
            WorkPerformance wp = WorkPerformanceRepository.checkWorkPerformance(employeeId);

            if (wp != null && wp.Id != id)
                return false;

            WorkPerformanceRepository.updateWorkPerformance(id, employeeId, detail);
            return true;
        }

        public static bool removeWorkPerformance(int id)
        {
            return WorkPerformanceRepository.removeWorkPerformance(id);
        }
    }
}
