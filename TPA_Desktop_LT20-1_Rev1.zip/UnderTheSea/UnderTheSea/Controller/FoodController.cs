﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class FoodController
    {
        public static List<Food> getAllFood()
        {
            return FoodRepository.getAllFood();
        }

        public static Food getOneFood(int id)
        {
            return FoodRepository.getOneFood(id);
        }
    }
}
