﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class ConstructionRequestController
    {
        public static List<ConstructionRequest> getAllConstructionRequest()
        {
            return ConstructionRequestRepository.getAllConstructionRequest();
        }

        public static bool addConstructionRequest(int ideaId)
        {
            CreativeIdea idea = CreativeIdeaRepository.getOneIdea(ideaId);

            if (idea == null || !idea.RideAndAttractionType.Equals("Ride") || !idea.Status.Equals("Accepted"))
                return false;

            ConstructionRequest cr = ConstructionRequestRepository.checkConstructionRequest(ideaId);

            if (cr != null)
                return true;

            DateTime date = DateTime.Now;
            cr = ConstructionRequestFactory.create(ideaId, date);
            return ConstructionRequestRepository.addConstructionRequest(cr);
        }
    }
}
