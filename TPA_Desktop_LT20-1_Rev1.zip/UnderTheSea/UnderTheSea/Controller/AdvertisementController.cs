﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.Singleton;

namespace UnderTheSea.Controller
{
    class AdvertisementController
    {
        public static List<Advertisement> getAllAdvertisement()
        {
            return AdvertisementRepository.getAllAdvertisement();
        }

        public static bool addAdvertisment(string detail)
        {
            int employeeId = EmployeeSingleton.getEmployeeData().Id;
            string status = "Active";
            DateTime date = DateTime.Now;

            Advertisement adv = AdvertisementFactory.create(employeeId, detail, date, status);
            return AdvertisementRepository.addAdvertisement(adv);
        }

        public static bool updateAdvertisement(int id, string detail)
        {
            int employeeId = EmployeeSingleton.getEmployeeData().Id;
            Advertisement adv = AdvertisementRepository.checkAdvertisement(id);

            if (adv == null || adv.Status.Equals("Removed"))
                return false;

            return AdvertisementRepository.updateAdvertisement(id, employeeId, detail);
        }

        public static bool removeAdvertisement(int id)
        {
            return AdvertisementRepository.removeAdvertisement(id);
        }
    }
}
