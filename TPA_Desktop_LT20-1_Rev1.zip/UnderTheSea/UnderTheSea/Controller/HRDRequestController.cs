﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Factory;
using UnderTheSea.Model;
using UnderTheSea.Repository;

namespace UnderTheSea.Controller
{
    class HRDRequestController
    {
        public static List<HRDRequest> getAllHRDRequest()
        {
            return HRDRequestRepository.getAllHRDRequest();
        }

        public static bool addHRDRequest(int employeeId, string type, string reason)
        {
            string status = "Waiting";
            DateTime date = DateTime.Now;
            string note = "";

            HRDRequest hrdr = HRDRequestFactory.create(employeeId, type, reason, status, date, note);
            return HRDRequestRepository.addHRDRequest(hrdr);
        }

        public static bool updateHRDRequest(int id, string status, string note)
        {
            return HRDRequestRepository.updateHRDRequest(id, status, note);
        }
    }
}
