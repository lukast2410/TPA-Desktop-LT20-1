﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class PurchaseInformationFactory
    {
        public static PurchaseInformation create(int employeeId, string information, DateTime date)
        {
            PurchaseInformation pi = new PurchaseInformation();
            pi.EmployeeId = employeeId;
            pi.Information = information;
            pi.Date = date;
            return pi;
        }
    }
}
