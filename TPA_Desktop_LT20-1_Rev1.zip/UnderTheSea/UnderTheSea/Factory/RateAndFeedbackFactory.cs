﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class RateAndFeedbackFactory
    {
        public static RateAndFeedback create(int rate, string feedback, DateTime date)
        {
            RateAndFeedback raf = new RateAndFeedback();
            raf.Rate = rate;
            raf.Feedback = feedback;
            raf.Date = date;
            return raf;
        }
    }
}
