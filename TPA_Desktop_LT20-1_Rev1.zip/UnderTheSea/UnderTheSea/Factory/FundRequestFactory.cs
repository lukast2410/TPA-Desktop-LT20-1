﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class FundRequestFactory
    {
        public static FundRequest create(int roleId, int totalAmount, string information, string status, DateTime date)
        {
            FundRequest fr = new FundRequest();
            fr.RoleId = roleId;
            fr.TotalAmount = totalAmount;
            fr.Information = information;
            fr.Status = status;
            fr.AddedDate = date;
            return fr;
        }
    }
}
