﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class OrderFactory
    {
        public static Order create(int tableNumber, int employeeId, DateTime date)
        {
            Order o = new Order();
            o.TableNumber = tableNumber;
            o.EmployeeId = employeeId;
            o.Date = date;
            return o;
        }
    }
}
