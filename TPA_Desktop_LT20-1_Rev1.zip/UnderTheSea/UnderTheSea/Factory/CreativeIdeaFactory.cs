﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class CreativeIdeaFactory
    {
        public static CreativeIdea create(string ideaType, string ideaName, string rideAndAttractionType, string ideaDetail, 
            string status, DateTime date)
        {
            CreativeIdea ci = new CreativeIdea();
            ci.IdeaType = ideaType;
            ci.IdeaName = ideaName;
            ci.IdeaDetail = ideaDetail;
            ci.RideAndAttractionType = rideAndAttractionType;
            ci.Status = status;
            ci.AddedDate = date;
            ci.Note = "";
            return ci;
        }
    }
}
