﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class WorklistHouseKeepingFactory
    {
        public static WorklistHouseKeeping create(int employeeId, int roomNumber, string detail, DateTime date)
        {
            WorklistHouseKeeping whk = new WorklistHouseKeeping();
            whk.EmployeeId = employeeId;
            whk.RoomNumber = roomNumber;
            whk.Detail = detail;
            whk.Date = date;
            return whk;
        }
    }
}
