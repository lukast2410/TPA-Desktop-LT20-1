﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class AdvertisementFactory
    {
        public static Advertisement create(int employeeId, string detail, DateTime date, string status)
        {
            Advertisement adv = new Advertisement();
            adv.EmployeeId = employeeId;
            adv.Detail = detail;
            adv.Date = date;
            adv.Status = status;
            return adv;
        }
    }
}
