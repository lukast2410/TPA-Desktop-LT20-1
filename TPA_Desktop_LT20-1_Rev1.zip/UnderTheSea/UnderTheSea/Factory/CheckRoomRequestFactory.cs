﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class CheckRoomRequestFactory
    {
        public static CheckRoomRequest create(int roomNumber, string status)
        {
            CheckRoomRequest crr = new CheckRoomRequest();
            crr.RoomNumber = roomNumber;
            crr.Status = status;
            return crr;
        }
    }
}
