﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class TicketFactory
    {
        public static Ticket create(DateTime expiredDate)
        {
            Ticket t = new Ticket();
            t.ExpiredDate = expiredDate;
            return t;
        }
    }
}
