﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class TicketTransactionFactory
    {
        public static TicketTransaction create(int employeeId, DateTime date, int quantity)
        {
            TicketTransaction transaction = new TicketTransaction();
            transaction.EmployeeId = employeeId;
            transaction.PurchaseDate = date;
            transaction.Quantity = quantity;
            return transaction;
        }
    }
}
