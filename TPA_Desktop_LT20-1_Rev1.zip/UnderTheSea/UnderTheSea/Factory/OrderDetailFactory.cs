﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class OrderDetailFactory
    {
        public static OrderDetail create(int orderId, int foodId, int quantity, string status)
        {
            OrderDetail od = new OrderDetail();
            od.FoodId = foodId;
            od.OrderId = orderId;
            od.Quantity = quantity;
            od.Status = status;
            return od;
        }
    }
}
