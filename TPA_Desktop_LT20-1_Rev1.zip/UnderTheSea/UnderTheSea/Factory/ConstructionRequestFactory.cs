﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class ConstructionRequestFactory
    {
        public static ConstructionRequest create(int ideaId, DateTime date)
        {
            ConstructionRequest cr = new ConstructionRequest();
            cr.IdeaId = ideaId;
            cr.Date = date;
            return cr;
        }
    }
}
