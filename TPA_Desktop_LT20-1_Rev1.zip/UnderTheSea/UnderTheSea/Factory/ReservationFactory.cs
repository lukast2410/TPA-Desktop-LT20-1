﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class ReservationFactory
    {
        public static Reservation create(int employeeId, int visitorId, int roomNumber, DateTime checkIn, DateTime checkOut, string status)
        {
            Reservation reserv = new Reservation();
            reserv.EmployeeId = employeeId;
            reserv.VisitorId = visitorId;
            reserv.RoomNumber = roomNumber;
            reserv.CheckInDate = checkIn;
            reserv.CheckOutDate = checkOut;
            reserv.Status = status;
            return reserv;
        }
    }
}
