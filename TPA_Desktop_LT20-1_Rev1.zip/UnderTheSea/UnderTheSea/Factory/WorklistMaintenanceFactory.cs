﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class WorklistMaintenanceFactory
    {
        public static WorklistMaintenance create(int rideAndAttractionId, string information, DateTime date, string status)
        {
            WorklistMaintenance wm = new WorklistMaintenance();
            wm.RideAndAttractionId = rideAndAttractionId;
            wm.Information = information;
            wm.AddedDate = date;
            wm.Status = status;
            return wm;
        }
    }
}
