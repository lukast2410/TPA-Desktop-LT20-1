﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class PersonalRequestFactory
    {
        public static PersonalRequest create(int employeeId, string type, string reason, string status, DateTime date, string note)
        {
            PersonalRequest pr = new PersonalRequest();
            pr.EmployeeId = employeeId;
            pr.Type = type;
            pr.Reason = reason;
            pr.Status = status;
            pr.AddedDate = date;
            pr.Note = note;
            return pr;
        }

    }
}
