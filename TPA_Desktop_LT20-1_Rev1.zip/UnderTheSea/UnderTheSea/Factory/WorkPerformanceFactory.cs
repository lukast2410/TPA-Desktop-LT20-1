﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class WorkPerformanceFactory
    {
        public static WorkPerformance create(int employeeId, string status, string detail)
        {
            WorkPerformance wp = new WorkPerformance();
            wp.EmployeeId = employeeId;
            wp.Status = status;
            wp.Detail = detail;
            return wp;
        }
    }
}
