﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class HRDRequestFactory
    {
        public static HRDRequest create(int employeeId, string type, string reason, string status, DateTime date, string note)
        {
            HRDRequest hrdr = new HRDRequest();
            hrdr.EmployeeId = employeeId;
            hrdr.Type = type;
            hrdr.Reason = reason;
            hrdr.Status = status;
            hrdr.AddedDate = date;
            hrdr.Note = note;
            return hrdr;
        }
    }
}
