﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class InboxFactory
    {
        public static Inbox create(string title, string content, int senderRoleId, int receiverRoleId, DateTime date)
        {
            Inbox ibx = new Inbox();
            ibx.Title = title;
            ibx.Content = content;
            ibx.SenderRoleId = senderRoleId;
            ibx.ReceiverRoleId = receiverRoleId;
            ibx.Date = date;
            return ibx;
        }
    }
}
