﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class EmployeeFactory
    {
        public static Employee create(string name, string email, string password, DateTime DOB, 
            string gender, string phone, int roleId, string status, int salary)
        {
            Employee emp = new Employee();
            emp.EmployeeName = name;
            emp.EmployeeEmail = email;
            emp.EmployeePassword = password;
            emp.DOB = DOB;
            emp.Gender = gender;
            emp.Phone = phone;
            emp.RoleId = roleId;
            emp.Status = status;
            emp.Salary = salary;
            return emp;
        }
    }
}
