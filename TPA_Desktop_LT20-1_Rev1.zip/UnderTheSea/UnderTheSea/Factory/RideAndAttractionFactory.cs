﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class RideAndAttractionFactory
    {
        public static RideAndAttraction create(string name, string detail, string status, string type)
        {
            RideAndAttraction raa = new RideAndAttraction();
            raa.Name = name;
            raa.Detail = detail;
            raa.Status = status;
            raa.Type = type;
            return raa;
        }
    }
}
