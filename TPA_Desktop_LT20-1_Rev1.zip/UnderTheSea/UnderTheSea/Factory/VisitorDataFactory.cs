﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class VisitorDataFactory
    {
        public static VisitorData create(string name, string identityNumber, string phone, string email, DateTime dob, string gender, string status)
        {
            VisitorData vd = new VisitorData();
            vd.Name = name;
            vd.Email = email;
            vd.DOB = dob;
            vd.Gender = gender;
            vd.Phone = phone;
            vd.Status = status;
            vd.IdentityNumber = identityNumber;
            return vd;
        }
    }
}
