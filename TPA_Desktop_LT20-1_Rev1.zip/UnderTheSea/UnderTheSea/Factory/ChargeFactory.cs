﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class ChargeFactory
    {
        public static Charge create(int employeeId, int visitorId, int price, string information, DateTime date)
        {
            Charge c = new Charge();
            c.EmployeeId = employeeId;
            c.VisitorId = visitorId;
            c.Price = price;
            c.Information = information;
            c.Date = date;
            return c;
        }
    }
}
