﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Factory
{
    class PurchaseRequestFactory
    {
        public static PurchaseRequest create(int roleId, string detail, string information, string status, DateTime date)
        {
            PurchaseRequest pr = new PurchaseRequest();
            pr.RoleId = roleId;
            pr.Detail = detail;
            pr.Information = information;
            pr.Status = status;
            pr.AddedDate = date;
            return pr;
        }
    }
}
