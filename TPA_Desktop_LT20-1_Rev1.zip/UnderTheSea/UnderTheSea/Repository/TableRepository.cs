﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class TableRepository
    {
        public static List<Table> getAllTable()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from tbl in db.Tables
                    select tbl).ToList();
        }

        public static bool changeTableStatus(int tableNumber, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Model.Table tbl = db.Tables.Where(x => x.TableNumber == tableNumber).FirstOrDefault();

            if (tbl == null)
                return false;

            tbl.Status = status;
            return db.SaveChanges() == 1;
        }

        public static Table checkTable(int tableNumber)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from tb in db.Tables
                    where tb.TableNumber == tableNumber
                    select tb).FirstOrDefault();
        }
    }
}
