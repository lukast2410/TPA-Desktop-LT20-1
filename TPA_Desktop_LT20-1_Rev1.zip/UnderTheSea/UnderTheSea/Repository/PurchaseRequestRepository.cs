﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class PurchaseRequestRepository
    {
        public static bool requestPurchase(PurchaseRequest pr)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.PurchaseRequests.Add(pr);
            return db.SaveChanges() == 1;
        }

        public static List<PurchaseRequest> getAllPurchaseRequest()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from pr in db.PurchaseRequests
                    select pr).ToList();
        }

        public static bool updatePurchaseRequestStatus(int id, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            PurchaseRequest pr = db.PurchaseRequests.Find(id);
            if (pr == null)
                return false;

            pr.Status = status;

            return db.SaveChanges() == 1;
        }
    }
}
