﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class OrderDetailRepository
    {
        public static List<OrderDetail> getAllOrderDetail()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from od in db.OrderDetails
                    select od).ToList();
        }

        public static bool updateOrderDetailStatus(int foodId, int orderId, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            OrderDetail odd = (from od in db.OrderDetails
                              where od.FoodId == foodId && od.OrderId == orderId
                              select od).FirstOrDefault();

            if (odd == null)
                return false;

            odd.Status = status;
            return db.SaveChanges() == 1;
        }

        public static bool updateOrderDetail(int foodId, int orderId, string status, int quantity)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            OrderDetail odd = (from od in db.OrderDetails
                               where od.FoodId == foodId && od.OrderId == orderId
                               select od).FirstOrDefault();

            if (odd == null)
                return false;

            odd.Status = status;
            odd.Quantity = quantity;

            return db.SaveChanges() == 1;
        }

        public static bool addOrderDetail(OrderDetail od)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.OrderDetails.Find(od);
            return db.SaveChanges() == 1;
        }

        public static OrderDetail checkOrderDetail(int foodId, int orderId)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from od in db.OrderDetails
                    where od.FoodId == foodId && od.OrderId == orderId
                    select od).FirstOrDefault();
        }
    }
}
