﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class PurchaseInformationRepository
    {
        public static List<PurchaseInformation> getAllPurchaseInformation()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from pi in db.PurchaseInformations
                    select pi).ToList();
        }

        public static bool addPurchaseInformation(PurchaseInformation pi)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.PurchaseInformations.Add(pi);
            return db.SaveChanges() == 1;
        }
    }
}
