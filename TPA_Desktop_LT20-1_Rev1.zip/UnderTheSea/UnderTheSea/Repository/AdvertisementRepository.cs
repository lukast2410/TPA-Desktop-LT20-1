﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class AdvertisementRepository
    {
        public static List<Advertisement> getAllAdvertisement()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from adv in db.Advertisements
                    where adv.Status != "Removed"
                    select adv).ToList();
        }

        public static bool addAdvertisement(Advertisement adv)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Advertisements.Add(adv);
            return db.SaveChanges() == 1;
        }

        public static bool updateAdvertisement(int id, int employeeId, string detail)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Advertisement adv = db.Advertisements.Find(id);

            if (adv == null)
                return false;

            adv.EmployeeId = employeeId;
            adv.Detail = detail;

            return db.SaveChanges() == 1;
        }

        public static bool removeAdvertisement(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Advertisement adv = db.Advertisements.Find(id);

            if (adv == null)
                return false;

            adv.Status = "Removed";

            return db.SaveChanges() == 1;
        }

        public static Advertisement checkAdvertisement(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.Advertisements.Find(id);
        }
    }
}
