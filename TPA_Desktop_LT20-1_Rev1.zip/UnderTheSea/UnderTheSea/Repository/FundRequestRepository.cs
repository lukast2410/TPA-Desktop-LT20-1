﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class FundRequestRepository
    {
        public static bool requestFund(FundRequest fr)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.FundRequests.Add(fr);
            return db.SaveChanges() == 1;
        }

        public static List<FundRequest> getAllFundRequest()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from fr in db.FundRequests
                    select fr).ToList();
        }

        public static bool updateFundRequestStatus(int id, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            FundRequest fr = db.FundRequests.Find(id);
            if (fr == null)
                return false;

            fr.Status = status;

            return db.SaveChanges() == 1;
        }
    }
}
