﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class CreativeIdeaRepository
    {
        public static List<CreativeIdea> getAllIdea()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from ci in db.CreativeIdeas
                    select ci).ToList();
        }

        public static bool addIdea(CreativeIdea idea)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.CreativeIdeas.Add(idea);
            return db.SaveChanges() == 1;
        }

        public static bool updateIdea(int id, string status, string note)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            CreativeIdea idea = db.CreativeIdeas.Find(id);

            if (idea == null)
                return false;

            idea.Status = status;
            idea.Note = note;

            return db.SaveChanges() == 1;
        }

        public static CreativeIdea getOneIdea(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.CreativeIdeas.Find(id);
        }
    }
}
