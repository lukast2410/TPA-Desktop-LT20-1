﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class ReservationRepository
    {
        public static List<Reservation> getAllReservation()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from reserv in db.Reservations
                    where reserv.Status != "Removed"
                    select reserv).ToList();
        }

        public static bool addReservation(Reservation reserv)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Reservations.Add(reserv);
            return db.SaveChanges() == 1;
        }

        public static bool updateReservation(int id, int employeeId, int visitorId, int roomNumber, DateTime checkIn, DateTime checkOut, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Reservation reserv = db.Reservations.Find(id);

            if (reserv == null)
                return false;

            reserv.EmployeeId = employeeId;
            reserv.VisitorId = visitorId;
            reserv.RoomNumber = roomNumber;
            reserv.CheckInDate = checkIn;
            reserv.CheckOutDate = checkOut;
            reserv.Status = status;

            return db.SaveChanges() == 1;
        }

        public static bool removeReservation(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Reservation reserv = db.Reservations.Find(id);

            if (reserv == null)
                return false;
            
            reserv.Status = "Removed";

            return db.SaveChanges() == 1;
        }

        public static bool updateReservationStatus(int id, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Reservation reserv = db.Reservations.Find(id);

            if (reserv == null)
                return false;

            reserv.Status = status;

            return db.SaveChanges() == 1;
        }

        public static Reservation getOneReservation(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.Reservations.Find(id);
        }
    }
}
