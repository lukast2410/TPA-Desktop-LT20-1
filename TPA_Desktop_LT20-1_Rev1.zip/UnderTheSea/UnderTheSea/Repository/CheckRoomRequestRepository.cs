﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class CheckRoomRequestRepository
    {
        public static List<CheckRoomRequest> getAllCheckRoomRequest()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from cr in db.CheckRoomRequests
                    select cr).ToList();
        }

        public static bool requestCheckRoom(CheckRoomRequest crr)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.CheckRoomRequests.Add(crr);
            return db.SaveChanges() == 1;
        }

        public static bool checkRoomDone(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            CheckRoomRequest crr = db.CheckRoomRequests.Find(id);

            if (crr == null)
                return false;

            crr.Status = "Done";
            return db.SaveChanges() == 1;
        }
    }
}
