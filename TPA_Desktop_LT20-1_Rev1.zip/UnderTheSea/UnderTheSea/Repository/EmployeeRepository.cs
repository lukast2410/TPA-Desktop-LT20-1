﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class EmployeeRepository
    {
        public static Employee login(string email, string password)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from employee in db.Employees
                    where employee.EmployeeEmail == email &&
                    employee.EmployeePassword == password
                    select employee).FirstOrDefault();
        }

        public static List<Employee> getAllEmployeeData()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from employee in db.Employees
                    select employee).ToList();
        }

        public static bool addEmployee(Employee emp)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Employees.Add(emp);
            return db.SaveChanges() == 1;
        }

        public static bool updateEmployee(int id, string name, string email, string password, DateTime DOB,
            string gender, string phone, int roleId, string status, int salary)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Employee emp = db.Employees.Find(id);

            if (emp == null)
                return false;

            emp.EmployeeName = name;
            emp.EmployeePassword = password;
            emp.EmployeeEmail = email;
            emp.DOB = DOB;
            emp.Gender = gender;
            emp.Status = status;
            emp.Phone = phone;
            emp.RoleId = roleId;
            emp.Salary = salary;

            return db.SaveChanges() == 1;
        }

        public static Employee checkEmployee(string email)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from employee in db.Employees
                    where employee.EmployeeEmail == email
                    select employee).FirstOrDefault();
        }
    }
}
