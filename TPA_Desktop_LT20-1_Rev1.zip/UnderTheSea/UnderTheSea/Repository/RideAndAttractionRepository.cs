﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class RideAndAttractionRepository
    {
        public static List<RideAndAttraction> getAllRideAndAttraction()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from raa in db.RideAndAttractions
                    where raa.Status != "Removed"
                    select raa).ToList();
        }

        public static List<RideAndAttraction> getAllRide()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from raa in db.RideAndAttractions
                    where raa.Type == "Ride" && raa.Status != "Removed"
                    select raa).ToList();
        }

        public static bool addRideAndAttraction(RideAndAttraction raa)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.RideAndAttractions.Add(raa);
            return db.SaveChanges() == 1;
        }

        public static bool updateRideAndAttraction(int id, string name, string detail, string status, string type)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            RideAndAttraction raa = db.RideAndAttractions.Find(id);

            if (raa == null)
                return false;

            raa.Name = name;
            raa.Detail = detail;
            raa.Status = status;
            raa.Type = type;

            return db.SaveChanges() == 1;
        }

        public static bool updateRideAndAttractionStatus(int id, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            RideAndAttraction raa = db.RideAndAttractions.Find(id);

            if (raa == null)
                return false;

            raa.Status = status;
            return db.SaveChanges() == 1;
        }

        public static bool removeRideAndAttraction(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            RideAndAttraction raa = db.RideAndAttractions.Find(id);

            if (raa == null)
                return false;

            raa.Status = "Removed";
            return db.SaveChanges() == 1;
        }

        public static RideAndAttraction getOneRideAndAttraction(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.RideAndAttractions.Find(id);
        }
    }
}
