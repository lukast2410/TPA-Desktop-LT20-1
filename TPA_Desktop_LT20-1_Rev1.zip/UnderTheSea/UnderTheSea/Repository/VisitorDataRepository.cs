﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class VisitorDataRepository
    {
        public static List<VisitorData> getAllVisitorData()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from vd in db.VisitorDatas
                    where vd.Status != "Removed"
                    select vd).ToList();
        }

        public static bool addVisitorData(VisitorData vd)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.VisitorDatas.Add(vd);
            return db.SaveChanges() == 1;
        }

        public static bool updateVisitorData(int id, string name, string identityNumber, string phone, string email, DateTime dob, string gender, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            VisitorData vd = db.VisitorDatas.Find(id);

            if (vd == null)
                return false;

            vd.Name = name;
            vd.IdentityNumber = identityNumber;
            vd.Phone = phone;
            vd.Email = email;
            vd.DOB = dob;
            vd.Gender = gender;
            vd.Status = status;

            return db.SaveChanges() == 1;
        }

        public static bool removeVisitorData(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            VisitorData vd = db.VisitorDatas.Find(id);

            if (vd == null)
                return false;

            vd.Status = "Removed";

            return db.SaveChanges() == 1;
        }

        public static VisitorData checkVisitor(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.VisitorDatas.Find(id);
        }
    }
}
