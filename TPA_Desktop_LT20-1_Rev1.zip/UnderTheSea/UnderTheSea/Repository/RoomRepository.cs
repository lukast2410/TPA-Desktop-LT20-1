﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class RoomRepository
    {
        public static List<Room> getAllRoom()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from r in db.Rooms
                    select r).ToList();
        }

        public static Room getRoom(int roomNumber)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from r in db.Rooms
                    where r.RoomNumber == roomNumber
                    select r).FirstOrDefault();
        }

        public static bool updateRoom(int roomNumber, int visitorId, DateTime checkOut, DateTime checkIn, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Room room = (from r in db.Rooms where r.RoomNumber == roomNumber select r).FirstOrDefault();

            if (room == null)
                return false;

            room.VisitorId = visitorId;
            room.CheckInDate = checkIn;
            room.CheckOutDate = checkOut;
            room.Status = status;

            return db.SaveChanges() == 1;
        }

        public static bool roomCheckOut(int roomNumber)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Room room = (from r in db.Rooms where r.RoomNumber == roomNumber select r).FirstOrDefault();

            if (room == null)
                return false;

            room.VisitorId = null;
            room.CheckInDate = null;
            room.CheckOutDate = null;
            room.Status = "Available";

            return db.SaveChanges() == 1;
        }

        public static bool updateRoomStatus(int roomNumber, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            Room room = (from r in db.Rooms where r.RoomNumber == roomNumber select r).FirstOrDefault();

            if (room == null)
                return false;

            room.Status = status;

            return db.SaveChanges() == 1;
        }
    }
}
