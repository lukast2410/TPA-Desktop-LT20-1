﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class WorklistHouseKeepingRepository
    {
        public static List<WorklistHouseKeeping> getAllWorklistHouseKeeping()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from wh in db.WorklistHouseKeepings
                    select wh).ToList();
        }

        public static bool addWorklistHouseKeeping(WorklistHouseKeeping whk)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.WorklistHouseKeepings.Add(whk);
            return db.SaveChanges() == 1;
        }
    }
}
