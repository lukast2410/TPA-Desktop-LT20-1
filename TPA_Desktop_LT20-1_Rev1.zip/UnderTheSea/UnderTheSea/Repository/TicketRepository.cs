﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class TicketRepository
    {
        public static bool generateTicket(Ticket t)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Tickets.Add(t);
            return db.SaveChanges() == 1;
        }

        public static Ticket getTicket(int code)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.Tickets.Find(code);
        }
    }
}
