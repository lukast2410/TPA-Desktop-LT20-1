﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class WorklistMaintenanceRepository
    {
        public static List<WorklistMaintenance> getAllWorklistMaintenance()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from wm in db.WorklistMaintenances
                    where wm.Status != "Removed"
                    select wm).ToList();
        }

        public static bool addWorklistMaintenance(WorklistMaintenance wm)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.WorklistMaintenances.Add(wm);
            return db.SaveChanges() == 1;
        }

        public static bool updateWorklistMaintenance(int id, int rideAndAttractionId, string information, string status)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            WorklistMaintenance wm = db.WorklistMaintenances.Find(id);

            if (wm == null)
                return false;

            wm.RideAndAttractionId = rideAndAttractionId;
            wm.Information = information;
            wm.Status = status;

            return db.SaveChanges() == 1;
        }

        public static bool removeWorklistMaintenance(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            WorklistMaintenance wm = db.WorklistMaintenances.Find(id);

            if (wm == null)
                return false;
            
            wm.Status = "Removed";

            return db.SaveChanges() == 1;
        }

        public static WorklistMaintenance checkWorklistMaintenance(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.WorklistMaintenances.Find(id);
        }
    }
}
