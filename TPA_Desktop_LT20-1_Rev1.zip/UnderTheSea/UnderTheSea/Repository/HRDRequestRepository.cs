﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class HRDRequestRepository
    {
        public static List<HRDRequest> getAllHRDRequest()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from hrdr in db.HRDRequests
                    select hrdr).ToList();
        }

        public static bool addHRDRequest(HRDRequest hrdr)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.HRDRequests.Add(hrdr);
            return db.SaveChanges() == 1;
        }

        public static bool updateHRDRequest(int id, string status, string note)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            HRDRequest hrdr = db.HRDRequests.Find(id);

            if (hrdr == null)
                return false;

            hrdr.Status = status;
            hrdr.Note = note;

            return db.SaveChanges() == 1;
        }
    }
}
