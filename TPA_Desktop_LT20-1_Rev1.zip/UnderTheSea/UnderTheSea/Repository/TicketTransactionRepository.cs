﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class TicketTransactionRepository
    {
        public static List<TicketTransaction> getAllTicketTransaction()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from transaction in db.TicketTransactions
                    select transaction).ToList();
        }

        public static bool addTicketTransaction(TicketTransaction transaction)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.TicketTransactions.Add(transaction);
            return db.SaveChanges() == 1;
        }
    }
}
