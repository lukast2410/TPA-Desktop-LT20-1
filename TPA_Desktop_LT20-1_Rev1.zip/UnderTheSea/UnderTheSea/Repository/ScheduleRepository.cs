﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class ScheduleRepository
    {
        public static List<Schedule> getAllSchedule()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from schedule in db.Schedules
                    select schedule).ToList();
        }
    }
}
