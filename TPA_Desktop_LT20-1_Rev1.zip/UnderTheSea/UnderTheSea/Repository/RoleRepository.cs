﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class RoleRepository
    {
        public static List<Role> getAllRole()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from role in db.Roles select role).ToList();
        }
    }
}
