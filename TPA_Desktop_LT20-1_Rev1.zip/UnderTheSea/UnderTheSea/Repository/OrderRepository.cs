﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class OrderRepository
    {
        public static List<OrderDetail> getAllOrderDetail()
        {
            return OrderDetailRepository.getAllOrderDetail();
        }

        public static bool updateOrderDetailStatus(int foodId, int orderId, string status)
        {
            return OrderDetailRepository.updateOrderDetailStatus(foodId, orderId, status);
        }

        public static bool updateOrderDetail(int foodId, int orderId, string status, int quantity)
        {
            return OrderDetailRepository.updateOrderDetail(foodId, orderId, status, quantity);
        }

        public static bool addOrderDetail(OrderDetail od)
        {
            return OrderDetailRepository.addOrderDetail(od);
        }

        public static bool createOrder(Order od)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Orders.Add(od);
            return db.SaveChanges() == 1;
        }

        public static OrderDetail checkOrderDetail(int foodId, int orderId)
        {
            return OrderDetailRepository.checkOrderDetail(foodId, orderId);
        }
    }
}
