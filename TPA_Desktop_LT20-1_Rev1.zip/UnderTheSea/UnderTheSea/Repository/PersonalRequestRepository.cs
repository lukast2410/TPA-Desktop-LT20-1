﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class PersonalRequestRepository
    {
        public static bool addPersonalRequest(PersonalRequest pr)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.PersonalRequests.Add(pr);
            return db.SaveChanges() == 1;
        }

        public static List<PersonalRequest> getMyPersonalRequest(int employeeId)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from pr in db.PersonalRequests
                    where pr.EmployeeId == employeeId
                    select pr).ToList();
        }

        public static List<PersonalRequest> getAllPersonalRequestByType(string type)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from pr in db.PersonalRequests
                    where pr.Type == type
                    select pr).ToList();
        }

        public static bool updatePersonalRequest(int id, string status, string note)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            PersonalRequest pr = db.PersonalRequests.Find(id);
            if (pr == null)
                return false;

            pr.Status = status;
            pr.Note = note;

            return db.SaveChanges() == 1;
        }

        public static PersonalRequest checkPersonalRequest(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.PersonalRequests.Find(id);
        }
    }
}
