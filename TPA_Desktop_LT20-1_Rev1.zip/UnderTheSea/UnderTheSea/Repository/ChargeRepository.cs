﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class ChargeRepository
    {
        public static bool charge(Charge c)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Charges.Add(c);
            return db.SaveChanges() == 1;
        }
    }
}
