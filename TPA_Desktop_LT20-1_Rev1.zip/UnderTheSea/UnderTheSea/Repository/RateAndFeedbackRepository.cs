﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class RateAndFeedbackRepository
    {
        public static List<RateAndFeedback> getAllRateAndFeedback()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from raf in db.RateAndFeedbacks
                    select raf).ToList();
        }

        public static bool addRateAndFeedback(RateAndFeedback raf)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.RateAndFeedbacks.Add(raf);
            return db.SaveChanges() == 1;
        }
    }
}
