﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class WorkPerformanceRepository
    {
        public static List<WorkPerformance> getAllWorkPerformance()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from wp in db.WorkPerformances
                    where wp.Status != "Removed"
                    select wp).ToList();
        }

        public static bool addWorkPerformance(WorkPerformance wp)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.WorkPerformances.Add(wp);
            return db.SaveChanges() == 1;
        }

        public static bool updateWorkPerformance(int id, int employeeId, string detail)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            WorkPerformance wp = db.WorkPerformances.Find(id);

            if (wp == null || wp.Status.Equals("Removed"))
                return false;

            wp.EmployeeId = employeeId;
            wp.Detail = detail;

            return db.SaveChanges() == 1;
        }

        public static bool removeWorkPerformance(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            WorkPerformance wp = db.WorkPerformances.Find(id);

            if (wp == null)
                return false;

            wp.Status = "Removed";

            return db.SaveChanges() == 1;
        }

        public static WorkPerformance checkWorkPerformance(int employeeId)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from wp in db.WorkPerformances
                    where wp.EmployeeId == employeeId &&
                    wp.Status != "Removed"
                    select wp).FirstOrDefault();
        }
        
    }
}
