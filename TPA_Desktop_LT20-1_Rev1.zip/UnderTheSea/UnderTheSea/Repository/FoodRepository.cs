﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class FoodRepository
    {
        public static List<Food> getAllFood()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from food in db.Foods
                    select food).ToList();
        }

        public static Food getOneFood(int foodId)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.Foods.Find(foodId);
        }
    }
}
