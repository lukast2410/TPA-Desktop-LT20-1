﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class InboxRepository
    {
        public static List<Inbox> getRoleInbox(int roleId)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from inbox in db.Inboxes
                    where inbox.ReceiverRoleId == roleId
                    select inbox).ToList();
        }

        public static Inbox getOneInbox(int id)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return db.Inboxes.Find(id);
        }

        public static bool sendMail(Inbox ibx)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.Inboxes.Add(ibx);
            return db.SaveChanges() == 1;
        }
    }
}
