﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.Repository
{
    class ConstructionRequestRepository
    {
        public static List<ConstructionRequest> getAllConstructionRequest()
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from cr in db.ConstructionRequests
                    select cr).ToList();
        }

        public static bool addConstructionRequest(ConstructionRequest cr)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            db.ConstructionRequests.Add(cr);
            return db.SaveChanges() == 1;
        }

        public static ConstructionRequest checkConstructionRequest(int ideaId)
        {
            UnderTheSeaEntities db = DatabaseSingleton.getInstance();
            return (from cr in db.ConstructionRequests
                    where cr.IdeaId == ideaId
                    select cr).FirstOrDefault();
        }
    }
}
