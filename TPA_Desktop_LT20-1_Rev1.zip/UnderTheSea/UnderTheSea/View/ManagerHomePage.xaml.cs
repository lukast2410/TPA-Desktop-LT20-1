﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManagerHomePage.xaml
    /// </summary>
    public partial class ManagerHomePage : Window
    {
        private static ManagerHomePage home = null;

        private ManagerHomePage()
        {
            InitializeComponent();
            Welcome.Text = "Hello, " + EmployeeSingleton.getEmployeeData().EmployeeName;
        }

        public static ManagerHomePage getInstance()
        {
            if (home == null)
            {
                home = new ManagerHomePage();
                home.Closed += delegate { home = null; };
            }

            return home;
        }

        public void showWindow()
        {
            if (home.WindowState == WindowState.Minimized)
                home.WindowState = WindowState.Normal;

            home.Focus();
            home.Show();
        }

        private void View_Income_Btn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void View_All_Employee_Data_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewAllEmployeeData vaed = ViewAllEmployeeData.getInstance();
            vaed.showWindow();
            this.Close();
        }

        private void View_All_Employee_Work_Performance_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewAllEmployeeWorkPerformance vaewp = ViewAllEmployeeWorkPerformance.getInstance();
            vaewp.showWindow();
            this.Close();
        }

        private void View_Resign_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewResignRequest vrr = ViewResignRequest.getInstance();
            vrr.showWindow();
            this.Close();
        }

        private void View_Request_From_HRD_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewRequestFromHRD vrfh = ViewRequestFromHRD.getInstance();
            vrfh.showWindow();
            this.Close();
        }

        private void View_Proposed_Idea_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewProposedIdea vpi = ViewProposedIdea.getInstance();
            vpi.showWindow();
            this.Close();
        }

        private void Logout_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.destroy();
            Login loginWindow = new Login();
            loginWindow.Show();
            this.Close();
        }
    }
}
