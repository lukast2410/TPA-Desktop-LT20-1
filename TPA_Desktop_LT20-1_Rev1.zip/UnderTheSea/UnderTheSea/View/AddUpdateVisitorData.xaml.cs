﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateVisitorData.xaml
    /// </summary>
    public partial class AddUpdateVisitorData : Window
    {
        private static AddUpdateVisitorData auvd = null;

        private AddUpdateVisitorData()
        {
            InitializeComponent();
        }

        public static AddUpdateVisitorData getInstance()
        {
            if (auvd == null)
            {
                auvd = new AddUpdateVisitorData();
                auvd.Closed += delegate { auvd = null; };
            }
            return auvd;
        }

        public void showWindow()
        {
            if (auvd.WindowState == WindowState.Minimized)
                auvd.WindowState = WindowState.Normal;

            auvd.Show();
            auvd.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string name = Name.Text;
            string email = Email.Text;
            DateTime dob = DOB.DisplayDate;
            string gender = "";
            string phone = Phone.Text;
            string status = ((ComboBoxItem)StatusComboBox.SelectedItem).Content.ToString();
            string identityText = IdentityNumber.Text;

            if (Male.IsChecked == true)
                gender = "Male";
            else if (Female.IsChecked == true)
                gender = "Female";

            if (name.Length == 0 || email.Length == 0|| DOB.SelectedDate == null || gender.Length == 0 ||
                phone.Length == 0 || status.Length == 0 || identityText.Length == 0)
            {
                MessageBox.Show("Form are not complete");
                return;
            }
            else if (email.IndexOf('@') == -1 || email.IndexOf('@') != email.IndexOf('@') || !email.EndsWith(".com") ||
               email.IndexOf('@') == (email.Length - 5) || email.IndexOf('@') == 0)
            {
                MessageBox.Show("Wrong email format");
                return;
            }
            else if (!phone.All(char.IsDigit))
            {
                MessageBox.Show("Phone must be numeric");
                return;
            }
            else if (!identityText.All(char.IsDigit))
            {
                MessageBox.Show("Identity Number must be numeric");
                return;
            }

            VisitorDataController.addVisitorData(name, identityText, phone, email, dob, gender, status);

            refreshData();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string employeeId = Id.Text;
            int id;
            bool parseId = int.TryParse(employeeId, out id);
            string name = Name.Text;
            string email = Email.Text;
            DateTime dob = DOB.DisplayDate;
            string gender = "";
            string phone = Phone.Text;
            string status = ((ComboBoxItem)StatusComboBox.SelectedItem).Content.ToString();
            string identityText = IdentityNumber.Text;

            if (Male.IsChecked == true)
                gender = "Male";
            else if (Female.IsChecked == true)
                gender = "Female";

            if (name.Length == 0 || email.Length == 0 || DOB.SelectedDate == null || gender.Length == 0 ||
                phone.Length == 0 || status.Length == 0 || identityText.Length == 0)
            {
                MessageBox.Show("Form are not complete");
                return;
            }
            else if (!parseId)
            {
                MessageBox.Show("Id must be number");
                return;
            }
            else if (email.IndexOf('@') == -1 || email.IndexOf('@') != email.IndexOf('@') || !email.EndsWith(".com") ||
               email.IndexOf('@') == (email.Length - 5) || email.IndexOf('@') == 0)
            {
                MessageBox.Show("Wrong email format");
                return;
            }
            else if (!phone.All(char.IsDigit))
            {
                MessageBox.Show("Phone must be numeric");
                return;
            }
            else if (!identityText.All(char.IsDigit))
            {
                MessageBox.Show("Identity Number must be numeric");
                return;
            }

            bool success = VisitorDataController.updateVisitorData(id, name, identityText, phone, email, dob, gender, status);

            if (!success)
                MessageBox.Show("Id Not Found");

            refreshData();
        }

        private void refreshData()
        {
            ManageVisitorData mvd = ManageVisitorData.getInstance();
            mvd.refreshData();
        }
    }
}
