﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageEmployeeData.xaml
    /// </summary>
    public partial class ManageEmployeeData : Window
    {
        private static ManageEmployeeData med = null;

        private ManageEmployeeData()
        {
            InitializeComponent();
            viewAllEmployeeData();
        }

        public static ManageEmployeeData getInstance()
        {
            if (med == null)
            {
                med = new ManageEmployeeData();
                med.Closed += delegate { med = null; };
            }
            return med;
        }

        public void showWindow()
        {
            if (med.WindowState == WindowState.Minimized)
                med.WindowState = WindowState.Normal;

            med.Show();
            med.Focus();
        }

        public void viewAllEmployeeData()
        {
            ViewEmployee.Items.Clear();

            List<Employee> employees = EmployeeController.getAllEmployeeData();

            foreach(Employee emp in employees)
            {
                ViewEmployee.Items.Add(emp);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Add_Update_Employee_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddUpdateEmployee aue = AddUpdateEmployee.getInstance();
            aue.showWindow();
        }
    }
}
