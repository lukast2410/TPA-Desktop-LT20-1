﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllPurchaseInformation.xaml
    /// </summary>
    public partial class ViewAllPurchaseInformation : Window
    {
        private static ViewAllPurchaseInformation vapi = null;

        private ViewAllPurchaseInformation()
        {
            InitializeComponent();
        }

        public static ViewAllPurchaseInformation getInstance()
        {
            if (vapi == null)
            {
                vapi = new ViewAllPurchaseInformation();
                vapi.Closed += delegate { vapi = null; };
            }
            return vapi;
        }

        public void showWindow()
        {
            if (vapi.WindowState == WindowState.Minimized)
                vapi.WindowState = WindowState.Normal;

            vapi.Show();
            vapi.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewPurchaseInformation.Items.Clear();

            List<PurchaseInformation> pi = PurchaseInformationController.getAllPurchaseInformation();

            foreach (PurchaseInformation p in pi)
            {
                ViewPurchaseInformation.Items.Add(p);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
