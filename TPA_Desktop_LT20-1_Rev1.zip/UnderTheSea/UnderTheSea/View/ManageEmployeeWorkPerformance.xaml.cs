﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageEmployeeWorkPerformance.xaml
    /// </summary>
    public partial class ManageEmployeeWorkPerformance : Window
    {
        private static ManageEmployeeWorkPerformance mewp = null;

        private ManageEmployeeWorkPerformance()
        {
            InitializeComponent();
        }

        public static ManageEmployeeWorkPerformance getInstance()
        {
            if (mewp == null)
            {
                mewp = new ManageEmployeeWorkPerformance();
                mewp.Closed += delegate { mewp = null; };
            }
            return mewp;
        }

        public void showWindow()
        {
            if (mewp.WindowState == WindowState.Minimized)
                mewp.WindowState = WindowState.Normal;

            mewp.Show();
            mewp.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewEmployeeWorkPerformance.Items.Clear();

            List<WorkPerformance> workPerformance = WorkPerformanceController.getAllWorkPerformance();

            foreach(WorkPerformance wp in workPerformance)
            {
                ViewEmployeeWorkPerformance.Items.Add(wp);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Add_Update_Work_Performance_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddUpdateWorkPerformance auwp = AddUpdateWorkPerformance.getInstance();
            auwp.showWindow();
        }

        private void Remove_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = RemoveId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success){
                MessageBox.Show("Id must be number");
                return;
            }

            WorkPerformanceController.removeWorkPerformance(id);

            refreshData();
        }
    }
}
