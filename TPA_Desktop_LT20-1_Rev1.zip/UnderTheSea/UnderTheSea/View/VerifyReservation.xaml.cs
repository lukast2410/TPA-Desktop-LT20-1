﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for VerifyReservation.xaml
    /// </summary>
    public partial class VerifyReservation : Window
    {
        private static VerifyReservation vr = null;
        private Reservation reserv = null;
        private string type;

        private VerifyReservation()
        {
            InitializeComponent();
        }

        public static VerifyReservation getInstance()
        {
            if (vr == null)
            {
                vr = new VerifyReservation();
                vr.Closed += delegate { vr = null; };
            }
            return vr;
        }


        public void showWindow()
        {
            if (vr.WindowState == WindowState.Minimized)
                vr.WindowState = WindowState.Normal;

            vr.Show();
            vr.Focus();
        }

        public void refreshData(Reservation r, string type, int nights)
        {
            this.type = type;
            this.reserv = r;
            Name.Text = r.VisitorData.Name;
            Room.Text = r.RoomNumber.ToString();
            CheckIn.Text = ((DateTime)r.CheckInDate).ToString("dd/MM/yyyy");
            CheckOut.Text = ((DateTime)r.CheckOutDate).ToString("dd/MM/yyyy");
            TotalPayment.Text = (r.Room.RoomPrice * nights).ToString();
        }

        private void Verify_Btn_Click(object sender, RoutedEventArgs e)
        {
            if (this.type.Equals("Add")){
                ReservationController.addReservation(this.reserv);
            }else if (this.type.Equals("Update")){
                ReservationController.updateReservation(reserv.Id, reserv);
            }
            this.Close();
        }

        private void Exit_Btn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
