﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewFundRequest.xaml
    /// </summary>
    public partial class ViewFundRequest : Window
    {
        private static ViewFundRequest vfr = null;

        private ViewFundRequest()
        {
            InitializeComponent();
        }

        public static ViewFundRequest getInstance()
        {
            if (vfr == null)
            {
                vfr = new ViewFundRequest();
                vfr.Closed += delegate { vfr = null; };
            }
            return vfr;
        }

        public void showWindow()
        {
            if (vfr.WindowState == WindowState.Minimized)
                vfr.WindowState = WindowState.Normal;

            vfr.Show();
            vfr.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewFundRequestData.Items.Clear();

            List<FundRequest> fr = FundRequestController.getAllFundRequest();

            foreach (FundRequest f in fr)
            {
                ViewFundRequestData.Items.Add(f);
            }
        }

        private void Accept_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            success = FundRequestController.updateFundRequestStatus(id, "Accepted");

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Reject_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            success = FundRequestController.updateFundRequestStatus(id, "Rejected");

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
