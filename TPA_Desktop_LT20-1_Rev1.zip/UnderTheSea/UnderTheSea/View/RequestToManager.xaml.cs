﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RequestToManager.xaml
    /// </summary>
    public partial class RequestToManager : Window
    {
        private static RequestToManager rtm = null;

        private RequestToManager()
        {
            InitializeComponent();
        }

        public static RequestToManager getInstance()
        {
            if (rtm == null)
            {
                rtm = new RequestToManager();
                rtm.Closed += delegate { rtm = null; };
            }
            return rtm;
        }

        public void showWindow()
        {
            if (rtm.WindowState == WindowState.Minimized)
                rtm.WindowState = WindowState.Normal;

            rtm.Show();
            rtm.Focus();
        }

        private void Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            string employeeIdText = EmployeeId.Text;
            int employeeId;
            bool success = int.TryParse(employeeIdText, out employeeId);
            string type = ((ComboBoxItem)SelectType.SelectedItem).Content.ToString();
            string reason = Reason.Text;

            if (!success) {
                MessageBox.Show("Id must be number");
                return;
            } else if (reason.Length == 0){
                MessageBox.Show("Please fill the reason");
                return;
            }

            success = HRDRequestController.addHRDRequest(employeeId, type, reason);
            if (!success)
                MessageBox.Show("Failed to request");

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
