﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateWorklistMaintenance.xaml
    /// </summary>
    public partial class AddUpdateWorklistMaintenance : Window
    {
        private static AddUpdateWorklistMaintenance auwm = null;

        private AddUpdateWorklistMaintenance()
        {
            InitializeComponent();
        }

        public static AddUpdateWorklistMaintenance getInstance()
        {
            if (auwm == null)
            {
                auwm = new AddUpdateWorklistMaintenance();
                auwm.Closed += delegate { auwm = null; };
            }
            return auwm;
        }

        public void showWindow()
        {
            if (auwm.WindowState == WindowState.Minimized)
                auwm.WindowState = WindowState.Normal;

            auwm.Show();
            auwm.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string rideAndAttractionIdText = RideAndAttractionId.Text;
            int rideAndAttractionId;
            bool parse = int.TryParse(rideAndAttractionIdText, out rideAndAttractionId);
            string status = ((ComboBoxItem)Status.SelectedItem).Content.ToString();
            string information = Information.Text;

            if (!parse)
            {
                MessageBox.Show("Ride or Attraction Id must be number");
                return;
            }

            WorklistMaintenanceController.addWorklistMaintenance(rideAndAttractionId, information, status);
            refreshData();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string rideAndAttractionIdText = RideAndAttractionId.Text;
            int rideAndAttractionId;
            bool parse = int.TryParse(rideAndAttractionIdText, out rideAndAttractionId);

            string status = ((ComboBoxItem)Status.SelectedItem).Content.ToString();
            string information = Information.Text;

            if (!parse)
            {
                MessageBox.Show("Ride or Attraction Id must be number");
                return;
            }
            else if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            WorklistMaintenanceController.updateWorklistMaintenance(id, rideAndAttractionId, information, status);
            if (!success)
                MessageBox.Show("Id Not Found");

            refreshData();
        }

        private void refreshData()
        {
            ManageWorklistMaintenance mwm = ManageWorklistMaintenance.getInstance();
            mwm.refreshData();
        }
    }
}
