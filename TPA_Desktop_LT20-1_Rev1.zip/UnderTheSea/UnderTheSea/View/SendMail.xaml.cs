﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for SendMail.xaml
    /// </summary>
    public partial class SendMail : Window
    {
        private static SendMail sm = null;

        private SendMail()
        {
            InitializeComponent();
            loadComboBoxItem();
        }

        public static SendMail getInstance()
        {
            if (sm == null)
            {
                sm = new SendMail();
                sm.Closed += delegate { sm = null; };
            }
            return sm;
        }

        public void showWindow()
        {
            if (sm.WindowState == WindowState.Minimized)
                sm.WindowState = WindowState.Normal;

            sm.Show();
            sm.Focus();
        }

        private void loadComboBoxItem()
        {
            ComboBoxItem item = new ComboBoxItem();
            item.Content = "Select Role";
            item.Tag = 0;
            SelectRole.Items.Add(item);

            int i = 0;
            foreach (Role role in RoleController.getAllRole())
            {
                i++;
                if (i == 2 || (i >= 4 && i <= 8))
                {
                    item = new ComboBoxItem();
                    item.Content = role.RoleName;
                    item.Tag = role.Id;
                    SelectRole.Items.Add(item);
                }
            }
        }

        private void Send_Mail_Btn_Click(object sender, RoutedEventArgs e)
        {
            int roleId = int.Parse(((ComboBoxItem)SelectRole.SelectedItem).Tag.ToString());
            string title = Title.Text;
            string content = Content.Text;

            if(title.Length == 0 || content.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }else if(roleId == 0){
                MessageBox.Show("Please select the role");
                return;
            }

            bool success = InboxController.sendMail(roleId, title, content);
            this.Close();

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
