﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddTicketTransaction.xaml
    /// </summary>
    public partial class AddTicketTransaction : Window
    {
        private static AddTicketTransaction att = null;

        private AddTicketTransaction()
        {
            InitializeComponent();
        }

        public static AddTicketTransaction getInstance()
        {
            if (att == null)
            {
                att = new AddTicketTransaction();
                att.Closed += delegate { att = null; };
            }
            return att;
        }

        public void showWindow()
        {
            if (att.WindowState == WindowState.Minimized)
                att.WindowState = WindowState.Normal;

            att.Show();
            att.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string quantityText = Quantity.Text;
            int quantity;
            bool success = int.TryParse(quantityText, out quantity);

            if (!success){
                MessageBox.Show("Quantity must be number");
                return;
            }

            TicketTransactionController.addTicketTransaction(quantity);
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
