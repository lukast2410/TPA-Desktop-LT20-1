﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ProposeIdeaToManager.xaml
    /// </summary>
    public partial class ProposeIdeaToManager : Window
    {
        private static ProposeIdeaToManager pitm = null;

        private ProposeIdeaToManager()
        {
            InitializeComponent();
        }

        public static ProposeIdeaToManager getInstance()
        {
            if (pitm == null)
            {
                pitm = new ProposeIdeaToManager();
                pitm.Closed += delegate { pitm = null; };
            }
            return pitm;
        }

        public void showWindow()
        {
            if (pitm.WindowState == WindowState.Minimized)
                pitm.WindowState = WindowState.Normal;

            pitm.Show();
            pitm.Focus();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Propose_Idea_Btn_Click(object sender, RoutedEventArgs e)
        {
            string ideaType = ((ComboBoxItem)IdeaType.SelectedItem).Content.ToString();
            string ideaName = IdeaName.Text;
            string rideOrAttraction = ((ComboBoxItem)RideOrAttraction.SelectedItem).Content.ToString();
            string ideaDetail = IdeaDetail.Text;

            if(ideaName.Length == 0 || ideaDetail.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }

            CreativeIdeaController.addIdea(ideaType, ideaName, rideOrAttraction, ideaDetail);

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
