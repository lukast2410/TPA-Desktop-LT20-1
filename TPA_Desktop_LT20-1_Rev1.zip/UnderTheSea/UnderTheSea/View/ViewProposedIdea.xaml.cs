﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewProposedIdea.xaml
    /// </summary>
    public partial class ViewProposedIdea : Window
    {
        private static ViewProposedIdea vpi = null;

        private ViewProposedIdea()
        {
            InitializeComponent();
        }

        public static ViewProposedIdea getInstance()
        {
            if (vpi == null)
            {
                vpi = new ViewProposedIdea();
                vpi.Closed += delegate { vpi = null; };
            }
            return vpi;
        }

        public void showWindow()
        {
            if (vpi.WindowState == WindowState.Minimized)
                vpi.WindowState = WindowState.Normal;

            vpi.Show();
            vpi.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewProposedIdeaData.Items.Clear();

            List<CreativeIdea> ci = CreativeIdeaController.getAllIdea();

            foreach (CreativeIdea c in ci)
            {
                ViewProposedIdeaData.Items.Add(c);
            }
        }

        private void Accept_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string note = Note.Text;

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }
            else if (note.Length == 0)
            {
                MessageBox.Show("Please fill the note");
                return;
            }

            success = CreativeIdeaController.updateIdea(id, "Accepted", note);

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Reject_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string note = Note.Text;

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }
            else if (note.Length == 0)
            {
                MessageBox.Show("Please fill the note");
                return;
            }

            success = CreativeIdeaController.updateIdea(id, "Rejected", note);

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
