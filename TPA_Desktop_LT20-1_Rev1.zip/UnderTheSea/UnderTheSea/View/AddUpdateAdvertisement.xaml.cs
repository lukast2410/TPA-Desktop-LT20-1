﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateAdvertisement.xaml
    /// </summary>
    public partial class AddUpdateAdvertisement : Window
    {
        private static AddUpdateAdvertisement aua = null;

        private AddUpdateAdvertisement()
        {
            InitializeComponent();
        }

        public static AddUpdateAdvertisement getInstance()
        {
            if (aua == null)
            {
                aua = new AddUpdateAdvertisement();
                aua.Closed += delegate { aua = null; };
            }
            return aua;
        }

        public void showWindow()
        {
            if (aua.WindowState == WindowState.Minimized)
                aua.WindowState = WindowState.Normal;

            aua.Show();
            aua.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string detail = Detail.Text;

            if(detail.Length == 0){
                MessageBox.Show("Detail must be filled");
                return;
            }

            AdvertisementController.addAdvertisment(detail);
            refreshData();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string detail = Detail.Text;

            if(detail.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }else if (!success){
                MessageBox.Show("Id must be number");
                return;
            }

            AdvertisementController.updateAdvertisement(id, detail);
            refreshData();
        }

        private void refreshData()
        {
            ManageAdvertisementData mad = ManageAdvertisementData.getInstance();
            mad.refreshData();
        }
    }
}
