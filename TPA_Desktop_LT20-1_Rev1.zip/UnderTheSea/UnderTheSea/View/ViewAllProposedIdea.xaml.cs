﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllProposedIdea.xaml
    /// </summary>
    public partial class ViewAllProposedIdea : Window
    {
        private static ViewAllProposedIdea vapi = null;

        private ViewAllProposedIdea()
        {
            InitializeComponent();
        }

        public static ViewAllProposedIdea getInstance()
        {
            if (vapi == null)
            {
                vapi = new ViewAllProposedIdea();
                vapi.Closed += delegate { vapi = null; };
            }
            return vapi;
        }

        public void showWindow()
        {
            if (vapi.WindowState == WindowState.Minimized)
                vapi.WindowState = WindowState.Normal;

            vapi.Show();
            vapi.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewProposedIdeaData.Items.Clear();

            List<CreativeIdea> ci = CreativeIdeaController.getAllIdea();

            foreach (CreativeIdea c in ci)
            {
                ViewProposedIdeaData.Items.Add(c);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Send_Ride_Idea_To_Construction_Btn_Click(object sender, RoutedEventArgs e)
        {
            string rideId = RideId.Text;
            int id;
            bool success = int.TryParse(rideId, out id);

            if (!success){
                MessageBox.Show("Idea Id must be number");
                return;
            }

            success = ConstructionRequestController.addConstructionRequest(id);
            if (!success)
                MessageBox.Show("Failed to send to construction");

            refreshData();
        }
    }
}
