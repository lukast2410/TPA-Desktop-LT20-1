﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for UpdateOrder.xaml
    /// </summary>
    public partial class UpdateOrder : Window
    {
        private static UpdateOrder uo = null;

        private UpdateOrder()
        {
            InitializeComponent();
        }

        public static UpdateOrder getInstance()
        {
            if (uo == null)
            {
                uo = new UpdateOrder();
                uo.Closed += delegate { uo = null; };
            }
            return uo;
        }

        public void showWindow()
        {
            if (uo.WindowState == WindowState.Minimized)
                uo.WindowState = WindowState.Normal;

            uo.Show();
            uo.Focus();
            refreshFoodData();
        }

        public void refreshFoodData()
        {
            ListFood.Items.Clear();

            List<Food> food = FoodController.getAllFood();

            foreach (Food f in food)
            {
                ListFood.Items.Add(f);
            }
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputOrderId = OrderId.Text;
            string inputFoodId = FoodId.Text;
            string qtyText = Quantity.Text;
            int quantity = 0;
            int foodId = 0;
            int orderId = 0;
            bool success = int.TryParse(inputOrderId, out orderId);
            if (success){
                success = int.TryParse(inputFoodId, out foodId);
                if (success)
                    success = int.TryParse(qtyText, out quantity);
            }
            string status = Status.Text;

            if (status.Length == 0)
            {
                MessageBox.Show("Form are not complete");
                return;
            }
            else if (!success)
            {
                MessageBox.Show("Wrong input!");
                return;
            }

            success = OrderController.updateOrderDetail(foodId, orderId, status, quantity);
            refreshData();
        }

        private void refreshData()
        {
            ManageOrder mwm = ManageOrder.getInstance();
            mwm.refreshData();
        }
    }
}
