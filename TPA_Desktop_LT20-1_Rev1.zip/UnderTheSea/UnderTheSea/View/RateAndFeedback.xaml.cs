﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RateAndFeedback.xaml
    /// </summary>
    public partial class RateAndFeedback : Window
    {
        private static RateAndFeedback raf = null;

        private RateAndFeedback()
        {
            InitializeComponent();
        }

        public static RateAndFeedback getInstance()
        {
            if (raf == null)
            {
                raf = new RateAndFeedback();
                raf.Closed += delegate { raf = null; };
            }
            return raf;
        }

        public void showWindow()
        {
            if (raf.WindowState == WindowState.Minimized)
                raf.WindowState = WindowState.Normal;

            raf.Show();
            raf.Focus();
        }

        private void Ok_Btn_Click(object sender, RoutedEventArgs e)
        {
            string rateText = ((ComboBoxItem)SelectRate.SelectedItem).Content.ToString();
            string feedback = Feedback.Text;
            int rate;
            bool success = int.TryParse(rateText, out rate);

            if (feedback.Length == 0)
            {
                MessageBox.Show("Please fill the feedback");
                return;
            }

            success = RateAndFeedbackController.addRateAndFeedback(rate, feedback);
            
            this.Close();
        }

        private void Exit_Btn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
