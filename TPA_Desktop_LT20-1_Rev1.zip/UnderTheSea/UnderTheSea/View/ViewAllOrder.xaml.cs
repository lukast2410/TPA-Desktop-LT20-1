﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllOrder.xaml
    /// </summary>
    public partial class ViewAllOrder : Window
    {
        private static ViewAllOrder vao = null;

        private ViewAllOrder()
        {
            InitializeComponent();
        }

        public static ViewAllOrder getInstance()
        {
            if (vao == null)
            {
                vao = new ViewAllOrder();
                vao.Closed += delegate { vao = null; };
            }
            return vao;
        }

        public void showWindow()
        {
            if (vao.WindowState == WindowState.Minimized)
                vao.WindowState = WindowState.Normal;

            vao.Show();
            vao.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ListOrderDetail.Items.Clear();

            List<OrderDetail> od = OrderController.getAllOrderDetail();

            foreach (OrderDetail o in od)
            {
                ListOrderDetail.Items.Add(o);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Update_Status_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputOrderId = OrderId.Text;
            string inputFoodId = FoodId.Text;
            int foodId = 0;
            int orderId = 0;
            bool success = int.TryParse(inputOrderId, out orderId);
            if (success)
                success = int.TryParse(inputFoodId, out foodId);
            string status = Status.Text;

            if (status.Length == 0)
            {
                MessageBox.Show("Form are not complete");
                return;
            }
            else if (!success)
            {
                MessageBox.Show("Order Id and Food Id must be number");
                return;
            }

            success = OrderController.updateOrderDetailStatus(foodId, orderId, status);
            refreshData();
        }
    }
}
