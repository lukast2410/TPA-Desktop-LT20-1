﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewLeavingPermitRequest.xaml
    /// </summary>
    public partial class ViewLeavingPermitRequest : Window
    {
        private static ViewLeavingPermitRequest vlpr = null;

        private ViewLeavingPermitRequest()
        {
            InitializeComponent();
        }

        public static ViewLeavingPermitRequest getInstance()
        {
            if (vlpr == null)
            {
                vlpr = new ViewLeavingPermitRequest();
                vlpr.Closed += delegate { vlpr = null; };
            }
            return vlpr;
        }

        public void showWindow()
        {
            if (vlpr.WindowState == WindowState.Minimized)
                vlpr.WindowState = WindowState.Normal;

            vlpr.Show();
            vlpr.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewLeavingPermitRequestData.Items.Clear();

            List<PersonalRequest> pr = PersonalRequestController.getLeavingPermitRequest();

            foreach (PersonalRequest p in pr)
            {
                ViewLeavingPermitRequestData.Items.Add(p);
            }
        }

        private void Accept_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string note = Note.Text;

            if (!success){
                MessageBox.Show("Id must be number");
                return;
            }else if(note.Length == 0){
                MessageBox.Show("Please fill the note");
                return;
            }

            success = PersonalRequestController.updateLeavingPermitRequest(id, "Accepted", note);

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Reject_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string note = Note.Text;

            if (!success){
                MessageBox.Show("Id must be number");
                return;
            }else if (note.Length == 0){
                MessageBox.Show("Please fill the note");
                return;
            }

            success = PersonalRequestController.updateLeavingPermitRequest(id, "Rejected", note);

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
