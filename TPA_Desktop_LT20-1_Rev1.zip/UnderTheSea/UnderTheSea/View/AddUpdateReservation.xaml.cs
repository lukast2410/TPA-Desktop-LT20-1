﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateReservation.xaml
    /// </summary>
    public partial class AddUpdateReservation : Window
    {
        private static AddUpdateReservation aur = null;

        private AddUpdateReservation()
        {
            InitializeComponent();
        }

        public static AddUpdateReservation getInstance()
        {
            if (aur == null)
            {
                aur = new AddUpdateReservation();
                aur.Closed += delegate { aur = null; };
            }
            return aur;
        }


        public void showWindow()
        {
            if (aur.WindowState == WindowState.Minimized)
                aur.WindowState = WindowState.Normal;

            aur.Show();
            aur.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ListVisitor.Items.Clear();

            List<VisitorData> vd = VisitorDataController.getAllVisitorData();

            foreach (VisitorData v in vd)
            {
                ListVisitor.Items.Add(v);
            }
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string visitorIdText = VisitorId.Text;
            string roomNumberText = RoomNumber.Text;
            string nightsText = Nights.Text;
            int visitorId = 0;
            int roomNumber = 0;
            int nights = 0;
            DateTime date = CheckIn.DisplayDate;

            bool success = int.TryParse(visitorIdText, out visitorId);
            if (success){
                success = int.TryParse(roomNumberText, out roomNumber);
                if (success)
                    success = int.TryParse(nightsText, out nights);
            }

            if(!success || CheckIn.SelectedDate == null){
                MessageBox.Show("Wrong input");
                return;
            }

            Reservation reserv = ReservationController.createReservation(visitorId, roomNumber, date, nights, "Booked");
            if(reserv == null){
                MessageBox.Show("Data Not Valid");
                return;
            }

            VerifyReservation vr = VerifyReservation.getInstance();
            vr.showWindow();
            vr.refreshData(reserv, "Add", nights);
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string visitorIdText = VisitorId.Text;
            string roomNumberText = RoomNumber.Text;
            string nightsText = Nights.Text;
            int visitorId = 0;
            int roomNumber = 0;
            int nights = 0;
            DateTime date = CheckIn.DisplayDate;

            bool success = int.TryParse(visitorIdText, out visitorId);
            if (success)
            {
                success = int.TryParse(roomNumberText, out roomNumber);
                if (success)
                    success = int.TryParse(nightsText, out nights);
            }

            if (!success || CheckIn.SelectedDate == null)
            {
                MessageBox.Show("Wrong input");
                return;
            }

            Reservation reserv = ReservationController.createReservation(visitorId, roomNumber, date, nights, "Booked");
            if (reserv == null)
            {
                MessageBox.Show("Data Not Valid");
                return;
            }

            VerifyReservation vr = VerifyReservation.getInstance();
            vr.showWindow();
            vr.refreshData(reserv, "Update", nights);
        }
    }
}
