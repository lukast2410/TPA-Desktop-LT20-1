﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllEmployeeData.xaml
    /// </summary>
    public partial class ViewAllEmployeeData : Window
    {
        private static ViewAllEmployeeData vaed = null;

        private ViewAllEmployeeData()
        {
            InitializeComponent();
        }

        public static ViewAllEmployeeData getInstance()
        {
            if (vaed == null)
            {
                vaed = new ViewAllEmployeeData();
                vaed.Closed += delegate { vaed = null; };
            }
            return vaed;
        }

        public void showWindow()
        {
            if (vaed.WindowState == WindowState.Minimized)
                vaed.WindowState = WindowState.Normal;

            vaed.Show();
            vaed.Focus();
            viewAllEmployeeData();
        }

        public void viewAllEmployeeData()
        {
            ViewEmployee.Items.Clear();
            
            List<Employee> employees = EmployeeController.getAllEmployeeData();

            foreach (Employee emp in employees)
            {
                ViewEmployee.Items.Add(emp);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
