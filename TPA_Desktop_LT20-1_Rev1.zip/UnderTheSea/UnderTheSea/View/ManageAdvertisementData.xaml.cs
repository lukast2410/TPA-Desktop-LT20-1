﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageAdvertisementData.xaml
    /// </summary>
    public partial class ManageAdvertisementData : Window
    {
        private static ManageAdvertisementData mad = null;

        private ManageAdvertisementData()
        {
            InitializeComponent();
        }

        public static ManageAdvertisementData getInstance()
        {
            if (mad == null)
            {
                mad = new ManageAdvertisementData();
                mad.Closed += delegate { mad = null; };
            }
            return mad;
        }

        public void showWindow()
        {
            if (mad.WindowState == WindowState.Minimized)
                mad.WindowState = WindowState.Normal;

            mad.Show();
            mad.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllAdvertisementData.Items.Clear();

            List<Advertisement> adv = AdvertisementController.getAllAdvertisement();

            foreach (Advertisement a in adv)
            {
                ViewAllAdvertisementData.Items.Add(a);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }


        private void Add_Update_Advertisement_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddUpdateAdvertisement aua = AddUpdateAdvertisement.getInstance();
            aua.showWindow();
        }

        private void Remove_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = RemoveId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            AdvertisementController.removeAdvertisement(id);

            refreshData();
        }
    }
}
