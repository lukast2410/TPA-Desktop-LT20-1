﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for CheckTable.xaml
    /// </summary>
    public partial class CheckTable : Window
    {
        private static CheckTable ct = null;

        private CheckTable()
        {
            InitializeComponent();
        }

        public static CheckTable getInstance()
        {
            if (ct == null)
            {
                ct = new CheckTable();
                ct.Closed += delegate { ct = null; };
            }
            return ct;
        }

        public void showWindow()
        {
            if (ct.WindowState == WindowState.Minimized)
                ct.WindowState = WindowState.Normal;

            ct.Show();
            ct.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ListTable.Items.Clear();

            List<Model.Table> tbl = TableController.getAllTable();

            foreach (Model.Table r in tbl)
            {
                ListTable.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Change_Table_Status_Btn_Click(object sender, RoutedEventArgs e)
        {
            string tableNumberText = TableNumber.Text;
            int tableNumber;
            bool success = int.TryParse(tableNumberText, out tableNumber);

            if (!success){
                MessageBox.Show("Table Number must be number");
                return;
            }

            success = TableController.changeTableStatus(tableNumber);
            if (!success)
                MessageBox.Show("Table Number not valid");

            refreshData();
        }
    }
}
