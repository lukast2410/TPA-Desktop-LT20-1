﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for MaintenanceHomePage.xaml
    /// </summary>
    public partial class MaintenanceHomePage : Window
    {
        private static MaintenanceHomePage home = null;

        private MaintenanceHomePage()
        {
            InitializeComponent();
            Welcome.Text = "Hello, " + EmployeeSingleton.getEmployeeData().EmployeeName;
        }

        public static MaintenanceHomePage getInstance()
        {
            if (home == null)
            {
                home = new MaintenanceHomePage();
                home.Closed += delegate { home = null; };
            }

            return home;
        }

        public void showWindow()
        {
            if (home.WindowState == WindowState.Minimized)
                home.WindowState = WindowState.Normal;

            home.Focus();
            home.Show();
        }

        private void View_All_Ride_And_Attraction_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewAllRideAndAttraction varaa = ViewAllRideAndAttraction.getInstance();
            varaa.showWindow();
            this.Close();
        }

        private void Manage_Worklist_Maintenance_Btn_Click(object sender, RoutedEventArgs e)
        {
            ManageWorklistMaintenance mwm = ManageWorklistMaintenance.getInstance();
            mwm.showWindow();
            this.Close();
        }

        private void View_Personal_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewPersonalRequest vpr = ViewPersonalRequest.getInstance();
            vpr.showWindow();
            this.Close();
        }

        private void Request_Leaving_Permit_Or_Resign_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestLeavingPermitOrResign rlpor = RequestLeavingPermitOrResign.getInstance();
            rlpor.showWindow();
            this.Close();
        }

        private void View_Schedule_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewSchedule vs = ViewSchedule.getInstance();
            vs.showWindow();
            this.Close();
        }

        private void Logout_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.destroy();
            Login loginWindow = new Login();
            loginWindow.Show();
            this.Close();
        }
    }
}
