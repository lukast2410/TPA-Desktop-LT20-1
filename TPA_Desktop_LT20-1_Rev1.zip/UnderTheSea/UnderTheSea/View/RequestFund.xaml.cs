﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RequestFund.xaml
    /// </summary>
    public partial class RequestFund : Window
    {
        private static RequestFund rf = null;

        private RequestFund()
        {
            InitializeComponent();
        }

        public static RequestFund getInstance()
        {
            if (rf == null)
            {
                rf = new RequestFund();
                rf.Closed += delegate { rf = null; };
            }
            return rf;
        }

        public void showWindow()
        {
            if (rf.WindowState == WindowState.Minimized)
                rf.WindowState = WindowState.Normal;

            rf.Show();
            rf.Focus();
        }

        private void Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            string totalAmountText = TotalAmount.Text;
            string information = Information.Text;
            int totalAmount;
            bool success = int.TryParse(totalAmountText, out totalAmount);

            if(totalAmountText.Length == 0 || information.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }else if (!success){
                MessageBox.Show("Total Amount must be number");
                return;
            }

            success = FundRequestController.requestFund(totalAmount, information);
            if (!success)
                MessageBox.Show("Fail to request");

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
