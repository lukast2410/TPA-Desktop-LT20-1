﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for FinanceHomePage.xaml
    /// </summary>
    public partial class FinanceHomePage : Window
    {
        private static FinanceHomePage fhp = null;

        private FinanceHomePage()
        {
            InitializeComponent();
            Welcome.Text = "Hello, " + EmployeeSingleton.getEmployeeData().EmployeeName;
        }

        public static FinanceHomePage getInstance()
        {
            if (fhp == null)
            {
                fhp = new FinanceHomePage();
                fhp.Closed += delegate { fhp = null; };
            }

            return fhp;
        }

        public void showWindow()
        {
            if (fhp.WindowState == WindowState.Minimized)
                fhp.WindowState = WindowState.Normal;

            fhp.Focus();
            fhp.Show();
        }

        private void View_Fund_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewFundRequest vfr = ViewFundRequest.getInstance();
            vfr.showWindow();
            this.Close();
        }

        private void Send_Mail_Btn_Click(object sender, RoutedEventArgs e)
        {
            SendMail sm = SendMail.getInstance();
            sm.showWindow();
        }

        private void View_Personal_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewPersonalRequest vpr = ViewPersonalRequest.getInstance();
            vpr.showWindow();
            this.Close();
        }

        private void Request_Leaving_Permit_Or_Resign_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestLeavingPermitOrResign rlpor = RequestLeavingPermitOrResign.getInstance();
            rlpor.showWindow();
            this.Close();
        }

        private void View_Schedule_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewSchedule vs = ViewSchedule.getInstance();
            vs.showWindow();
            this.Close();
        }

        private void Logout_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.destroy();
            Login loginWindow = new Login();
            loginWindow.Show();
            this.Close();
        }
    }
}
