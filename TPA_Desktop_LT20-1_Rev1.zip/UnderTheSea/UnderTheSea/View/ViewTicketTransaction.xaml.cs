﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageTicketTransaction.xaml
    /// </summary>
    public partial class ViewTicketTransaction : Window
    {
        private static ViewTicketTransaction mtt = null;

        private ViewTicketTransaction()
        {
            InitializeComponent();
        }

        public static ViewTicketTransaction getInstance()
        {
            if (mtt == null)
            {
                mtt = new ViewTicketTransaction();
                mtt.Closed += delegate { mtt = null; };
            }
            return mtt;
        }

        public void showWindow()
        {
            if (mtt.WindowState == WindowState.Minimized)
                mtt.WindowState = WindowState.Normal;

            mtt.Show();
            mtt.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewTicketTransactionData.Items.Clear();

            List<TicketTransaction> transaction = TicketTransactionController.getAllTicketTransaction();

            foreach (TicketTransaction tr in transaction)
            {
                ViewTicketTransactionData.Items.Add(tr);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
