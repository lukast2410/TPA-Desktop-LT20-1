﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewRoomsData.xaml
    /// </summary>
    public partial class ViewRoomsData : Window
    {
        private static ViewRoomsData vrd = null;

        private ViewRoomsData()
        {
            InitializeComponent();
        }

        public static ViewRoomsData getInstance()
        {
            if (vrd == null)
            {
                vrd = new ViewRoomsData();
                vrd.Closed += delegate { vrd = null; };
            }
            return vrd;
        }

        public void showWindow()
        {
            if (vrd.WindowState == WindowState.Minimized)
                vrd.WindowState = WindowState.Normal;

            vrd.Show();
            vrd.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllRoomData.Items.Clear();

            List<Room> room = RoomController.getAllRoom();

            foreach (Room r in room)
            {
                ViewAllRoomData.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
