﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateRideAndAttraction.xaml
    /// </summary>
    public partial class AddUpdateRideAndAttraction : Window
    {
        private static AddUpdateRideAndAttraction auraa = null;

        private AddUpdateRideAndAttraction()
        {
            InitializeComponent();
        }

        public static AddUpdateRideAndAttraction getInstance()
        {
            if (auraa == null)
            {
                auraa = new AddUpdateRideAndAttraction();
                auraa.Closed += delegate { auraa = null; };
            }
            return auraa;
        }

        public void showWindow()
        {
            if (auraa.WindowState == WindowState.Minimized)
                auraa.WindowState = WindowState.Normal;

            auraa.Show();
            auraa.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string name = Name.Text;
            string type = ((ComboBoxItem)Type.SelectedItem).Content.ToString();
            string detail = Detail.Text;
            string status = Status.Text;

            if (detail.Length == 0 || name.Length == 0 || status.Length == 0)
            {
                MessageBox.Show("Form are not complete");
                return;
            }

            RideAndAttractionController.addRideAndAttraction(name, detail, status, type);
            refreshData();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string name = Name.Text;
            string type = ((ComboBoxItem)Type.SelectedItem).Content.ToString();
            string detail = Detail.Text;
            string status = Status.Text;

            if (detail.Length == 0 || name.Length == 0 || status.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }else if (!success){
                MessageBox.Show("Id must be number");
                return;
            }

            success = RideAndAttractionController.updateRideAndAttraction(id, name, detail, status, type);

            if (!success)
                MessageBox.Show("Id Not Found");

            refreshData();
        }

        private void refreshData()
        {
            ManageRideAndAttraction mraa = ManageRideAndAttraction.getInstance();
            mraa.refreshData();
        }
    }
}
