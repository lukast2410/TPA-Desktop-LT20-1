﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RequestLeavingPermitOrResign.xaml
    /// </summary>
    public partial class RequestLeavingPermitOrResign : Window
    {
        private static RequestLeavingPermitOrResign rlpor = null;

        private RequestLeavingPermitOrResign()
        {
            InitializeComponent();
        }

        public static RequestLeavingPermitOrResign getInstance()
        {
            if (rlpor == null)
            {
                rlpor = new RequestLeavingPermitOrResign();
                rlpor.Closed += delegate { rlpor = null; };
            }
            return rlpor;
        }

        public void showWindow()
        {
            if (rlpor.WindowState == WindowState.Minimized)
                rlpor.WindowState = WindowState.Normal;

            rlpor.Show();
            rlpor.Focus();
        }

        private void Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            string type = ((ComboBoxItem)SelectType.SelectedItem).Content.ToString();
            string reason = Reason.Text;

            if(reason.Length == 0){
                MessageBox.Show("Please fill the reason");
                return;
            }

            bool success = PersonalRequestController.addPersonalRequest(type, reason);
            if(!success)
                MessageBox.Show("Failed to request");

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
