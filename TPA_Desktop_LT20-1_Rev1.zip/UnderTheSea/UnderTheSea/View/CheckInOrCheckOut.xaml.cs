﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for CheckInOrCheckOut.xaml
    /// </summary>
    public partial class CheckInOrCheckOut : Window
    {
        private static CheckInOrCheckOut cico = null;

        private CheckInOrCheckOut()
        {
            InitializeComponent();
        }

        public static CheckInOrCheckOut getInstance()
        {
            if (cico == null)
            {
                cico = new CheckInOrCheckOut();
                cico.Closed += delegate { cico = null; };
            }
            return cico;
        }

        public void showWindow()
        {
            if (cico.WindowState == WindowState.Minimized)
                cico.WindowState = WindowState.Normal;

            cico.Show();
            cico.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllReservationData.Items.Clear();

            List<Reservation> reserv = ReservationController.getAllReservation();

            foreach (Reservation r in reserv)
            {
                ViewAllReservationData.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Check_In_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success){
                MessageBox.Show("Id must be number");
                return;
            }

            success = ReservationController.checkIn(id);

            if (!success)
                MessageBox.Show("Data not valid");

            refreshData();
        }

        private void Check_Out_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            success = ReservationController.checkOut(id);

            if (!success)
                MessageBox.Show("Data not valid");

            RateAndFeedback raf = RateAndFeedback.getInstance();
            raf.showWindow();
            refreshData();
        }
    }
}
