﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for HRDHomePage.xaml
    /// </summary>
    public partial class HRDHomePage : Window
    {
        private static HRDHomePage home = null;

        private HRDHomePage()
        {
            InitializeComponent();
            Welcome.Text = "Hello, " + EmployeeSingleton.getEmployeeData().EmployeeName;
        }

        public static HRDHomePage getInstance()
        {
            if (home == null)
            {
                home = new HRDHomePage();
                home.Closed += delegate { home = null; };
            }

            return home;
        }

        public void showWindow()
        {
            if (home.WindowState == WindowState.Minimized)
                home.WindowState = WindowState.Normal;

            home.Focus();
            home.Show();
        }

        private void View_Inbox_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewInbox vi = ViewInbox.getInstance();
            vi.showWindow();
            this.Close();
        }

        private void Manage_Employee_Btn_Click(object sender, RoutedEventArgs e)
        {
            ManageEmployeeData med = ManageEmployeeData.getInstance();
            med.showWindow();
            this.Close();
        }

        private void Manage_Employee_Work_Performance_Btn_Click(object sender, RoutedEventArgs e)
        {
            ManageEmployeeWorkPerformance mewp = ManageEmployeeWorkPerformance.getInstance();
            mewp.showWindow();
            this.Close();
        }

        private void View_Leaving_Permit_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewLeavingPermitRequest vlpr = ViewLeavingPermitRequest.getInstance();
            vlpr.showWindow();
            this.Close();
        }

        private void Request_Fund_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestFund rf = RequestFund.getInstance();
            rf.showWindow();
            this.Close();
        }

        private void Request_To_Manager_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestToManager rtm = RequestToManager.getInstance();
            rtm.showWindow();
            this.Close();
        }

        private void View_Request_Response_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewRequestResponse vrr = ViewRequestResponse.getInstance();
            vrr.showWindow();
            this.Close();
        }

        private void Manage_Schedule_Btn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Logout_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.destroy();
            Login loginWindow = new Login();
            loginWindow.Show();
            this.Close();
        }

        private void View_Personal_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewPersonalRequest vpr = ViewPersonalRequest.getInstance();
            vpr.showWindow();
            this.Close();
        }

        private void Request_Leaving_Permit_Or_Resign_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestLeavingPermitOrResign rlpor = RequestLeavingPermitOrResign.getInstance();
            rlpor.showWindow();
            this.Close();
        }

        private void View_Schedule_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewSchedule vs = ViewSchedule.getInstance();
            vs.showWindow();
            this.Close();
        }
    }
}
