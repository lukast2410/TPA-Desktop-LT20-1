﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddNewOrder.xaml
    /// </summary>
    public partial class AddNewOrder : Window
    {
        private List<int> listFoodId = null;
        private List<int> listQty = null;
        private static AddNewOrder ano = null;

        private AddNewOrder()
        {
            InitializeComponent();
        }

        public static AddNewOrder getInstance()
        {
            if (ano == null)
            {
                ano = new AddNewOrder();
                ano.Closed += delegate { ano = null; };
            }
            return ano;
        }

        public void showWindow()
        {
            if (ano.WindowState == WindowState.Minimized)
                ano.WindowState = WindowState.Normal;

            ano.Show();
            ano.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ListFood.Items.Clear();

            List<Food> food = FoodController.getAllFood();

            foreach (Food f in food)
            {
                ListFood.Items.Add(f);
            }
        }

        private void Exit_Btn_Click(object sender, RoutedEventArgs e)
        {
            refreshOrderData();
            listFoodId = null;
            listQty = null;
            this.Close();
        }

        private void Finish_Order_Btn_Click(object sender, RoutedEventArgs e)
        {
            if(listFoodId == null){
                MessageBox.Show("Please add food first");
                return;
            }

            string tableNumberText = TableNumber.Text;
            int tableNumber = 0;
            bool success = int.TryParse(tableNumberText, out tableNumber);
            if (!success || TableController.checkTable(tableNumber) == null){
                MessageBox.Show("Table Number not valid");
                return;
            }

            Order od = OrderController.createOrder(tableNumber);
            for(int i = 0; i < listQty.Count; i++){
                OrderController.addOrderDetail(listFoodId[i], od.Id, listQty[i]);
            }

            listFoodId = null;
            listQty = null;
            refreshOrderData();
            this.Close();
        }

        private void Add_Food_Btn_Click(object sender, RoutedEventArgs e)
        {

            string inputFoodId = FoodId.Text;
            string qtyText = Quantity.Text;
            int foodId = 0;
            int quantity = 0;

            bool success = int.TryParse(inputFoodId, out foodId);
            if (success)
                success = int.TryParse(qtyText, out quantity);

            if (!success){
                MessageBox.Show("Wrong input!");
                return;
            }if(FoodController.getOneFood(foodId) == null){
                MessageBox.Show("Food Not Found!");
                return;
            }

            if (listFoodId == null){
                listFoodId = new List<int>();
                listQty = new List<int>();
            }

            listFoodId.Add(foodId);
            listQty.Add(quantity);
        }

        private void refreshOrderData()
        {
            ManageOrder mwm = ManageOrder.getInstance();
            mwm.refreshData();
        }
    }
}
