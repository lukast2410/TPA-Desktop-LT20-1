﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for UpdateRoomStatus.xaml
    /// </summary>
    public partial class UpdateRoomStatus : Window
    {
        private static UpdateRoomStatus urs = null;

        private UpdateRoomStatus()
        {
            InitializeComponent();
        }

        public static UpdateRoomStatus getInstance()
        {
            if (urs == null)
            {
                urs = new UpdateRoomStatus();
                urs.Closed += delegate { urs = null; };
            }
            return urs;
        }

        public void showWindow()
        {
            if (urs.WindowState == WindowState.Minimized)
                urs.WindowState = WindowState.Normal;

            urs.Show();
            urs.Focus();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string roomNumberText = RoomNumber.Text;
            int roomNumber;
            bool success = int.TryParse(roomNumberText, out roomNumber);
            string status = ((ComboBoxItem)SelectStatus.SelectedItem).Content.ToString();

            if (!success)
            {
                MessageBox.Show("Room Number must be number");
                return;
            }

            success = RoomController.updateRoomStatus(roomNumber, status);
            if (!success)
                MessageBox.Show("Failed to request");

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
