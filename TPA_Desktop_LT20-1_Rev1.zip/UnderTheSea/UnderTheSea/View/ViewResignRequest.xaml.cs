﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewResignRequest.xaml
    /// </summary>
    public partial class ViewResignRequest : Window
    {
        private static ViewResignRequest vrr = null;

        private ViewResignRequest()
        {
            InitializeComponent();
        }

        public static ViewResignRequest getInstance()
        {
            if (vrr == null)
            {
                vrr = new ViewResignRequest();
                vrr.Closed += delegate { vrr = null; };
            }
            return vrr;
        }

        public void showWindow()
        {
            if (vrr.WindowState == WindowState.Minimized)
                vrr.WindowState = WindowState.Normal;

            vrr.Show();
            vrr.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewResignRequestData.Items.Clear();

            List<PersonalRequest> pr = PersonalRequestController.getResignRequest();

            foreach (PersonalRequest p in pr)
            {
                ViewResignRequestData.Items.Add(p);
            }
        }

        private void Accept_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string note = Note.Text;

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }
            else if (note.Length == 0)
            {
                MessageBox.Show("Please fill the note");
                return;
            }

            success = PersonalRequestController.updateResignRequest(id, "Accepted", note);

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Reject_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string note = Note.Text;

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }
            else if (note.Length == 0)
            {
                MessageBox.Show("Please fill the note");
                return;
            }

            success = PersonalRequestController.updateResignRequest(id, "Rejected", note);

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
