﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
            if (EmployeeSingleton.getEmployeeData() != null)
                EmployeeSingleton.goToRoleHome();
        }

        private void Login_Btn_Click(object sender, RoutedEventArgs e)
        {
            string password = Password.Password.ToString();
            string email = Email.Text;

            Employee emp = EmployeeController.login(email, password);
            if (emp == null){
                MessageBox.Show("Invalid Email or Password");
                return;
            }

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
