﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewCheckRoomRequest.xaml
    /// </summary>
    public partial class ViewCheckRoomRequest : Window
    {
        private static ViewCheckRoomRequest vcrr = null;

        private ViewCheckRoomRequest()
        {
            InitializeComponent();
        }

        public static ViewCheckRoomRequest getInstance()
        {
            if (vcrr == null)
            {
                vcrr = new ViewCheckRoomRequest();
                vcrr.Closed += delegate { vcrr = null; };
            }
            return vcrr;
        }

        public void showWindow()
        {
            if (vcrr.WindowState == WindowState.Minimized)
                vcrr.WindowState = WindowState.Normal;

            vcrr.Show();
            vcrr.Focus();
            refreshData();
        }

        public void refreshData()
        {
            AllCheckRoomRequest.Items.Clear();

            List<CheckRoomRequest> crr = CheckRoomRequestController.getAllCheckRoomRequest();

            foreach (CheckRoomRequest c in crr)
            {
                AllCheckRoomRequest.Items.Add(c);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Done_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = DoneId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            CheckRoomRequestController.checkRoomDone(id);
        }

        private void Refresh_Btn_Click(object sender, RoutedEventArgs e)
        {
            refreshData();
        }
    }
}
