﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for KitchenDivision.xaml
    /// </summary>
    public partial class KitchenDivision : Window
    {
        private static KitchenDivision home = null;

        private KitchenDivision()
        {
            InitializeComponent();
            Welcome.Text = "Hello, " + EmployeeSingleton.getEmployeeData().EmployeeName;
        }

        public static KitchenDivision getInstance()
        {
            if (home == null)
            {
                home = new KitchenDivision();
                home.Closed += delegate { home = null; };
            }

            return home;
        }

        public void showWindow()
        {
            if (home.WindowState == WindowState.Minimized)
                home.WindowState = WindowState.Normal;

            home.Focus();
            home.Show();
        }

        private void Logout_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.destroy();
            Login loginWindow = new Login();
            loginWindow.Show();
            this.Close();
        }

        private void View_Personal_Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewPersonalRequest vpr = ViewPersonalRequest.getInstance();
            vpr.showWindow();
            this.Close();
        }

        private void Request_Leaving_Permit_Or_Resign_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestLeavingPermitOrResign rlpor = RequestLeavingPermitOrResign.getInstance();
            rlpor.showWindow();
            this.Close();
        }

        private void View_Schedule_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewSchedule vs = ViewSchedule.getInstance();
            vs.showWindow();
            this.Close();
        }

        private void View_Rate_And_Feedback_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewRateAndFeedBack vraf = ViewRateAndFeedBack.getInstance();
            vraf.showWindow();
            this.Close();
        }

        private void View_All_Order_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewAllOrder vao = ViewAllOrder.getInstance();
            vao.showWindow();
            this.Close();
        }

        private void Request_Purchase_Btn_Click(object sender, RoutedEventArgs e)
        {
            RequestPurchase rp = RequestPurchase.getInstance();
            rp.showWindow();
            this.Close();
        }

        private void View_Inbox_Btn_Click(object sender, RoutedEventArgs e)
        {
            ViewInbox vi = ViewInbox.getInstance();
            vi.showWindow();
            this.Close();
        }
    }
}
