﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewPersonalRequest.xaml
    /// </summary>
    public partial class ViewPersonalRequest : Window
    {
        private static ViewPersonalRequest vpr = null;

        private ViewPersonalRequest()
        {
            InitializeComponent();
        }

        public static ViewPersonalRequest getInstance()
        {
            if (vpr == null)
            {
                vpr = new ViewPersonalRequest();
                vpr.Closed += delegate { vpr = null; };
            }
            return vpr;
        }

        public void showWindow()
        {
            if (vpr.WindowState == WindowState.Minimized)
                vpr.WindowState = WindowState.Normal;

            vpr.Show();
            vpr.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewPersonalRequestData.Items.Clear();

            List<PersonalRequest> pr = PersonalRequestController.getMyPersonalRequest();

            foreach(PersonalRequest p in pr)
            {
                ViewPersonalRequestData.Items.Add(p);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
