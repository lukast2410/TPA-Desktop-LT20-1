﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewRateAndFeedBack.xaml
    /// </summary>
    public partial class ViewRateAndFeedBack : Window
    {
        private static ViewRateAndFeedBack vraf = null;

        private ViewRateAndFeedBack()
        {
            InitializeComponent();
        }

        public static ViewRateAndFeedBack getInstance()
        {
            if (vraf == null)
            {
                vraf = new ViewRateAndFeedBack();
                vraf.Closed += delegate { vraf = null; };
            }
            return vraf;
        }

        public void showWindow()
        {
            if (vraf.WindowState == WindowState.Minimized)
                vraf.WindowState = WindowState.Normal;

            vraf.Show();
            vraf.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewAllRateAndFeedback.Items.Clear();

            List<Model.RateAndFeedback> raf = RateAndFeedbackController.getAllRateAndFeedback();

            foreach (Model.RateAndFeedback r in raf)
            {
                ViewAllRateAndFeedback.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
