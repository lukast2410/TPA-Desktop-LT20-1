﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for UpdateRideStatus.xaml
    /// </summary>
    public partial class UpdateRideStatus : Window
    {
        private static UpdateRideStatus urs = null;

        private UpdateRideStatus()
        {
            InitializeComponent();
        }

        public static UpdateRideStatus getInstance()
        {
            if (urs == null)
            {
                urs = new UpdateRideStatus();
                urs.Closed += delegate { urs = null; };
            }
            return urs;
        }

        public void showWindow()
        {
            if (urs.WindowState == WindowState.Minimized)
                urs.WindowState = WindowState.Normal;

            urs.Show();
            urs.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ListRide.Items.Clear();

            List<RideAndAttraction> raa = RideAndAttractionController.getAllRide();

            foreach (RideAndAttraction r in raa)
            {
                ListRide.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Update_Ride_Status_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = RideId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);
            string status = Status.Text;

            if(status.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }else if (!success){
                MessageBox.Show("Id must be number");
                return;
            }

            success = RideAndAttractionController.updateRideStatus(id, status);
            if (!success)
                MessageBox.Show("Please input Id of Ride");

            refreshData();
        }
    }
}
