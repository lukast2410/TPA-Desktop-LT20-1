﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddPurchaseInformation.xaml
    /// </summary>
    public partial class AddPurchaseInformation : Window
    {
        private static AddPurchaseInformation api = null;

        private AddPurchaseInformation()
        {
            InitializeComponent();
        }
        
        public static AddPurchaseInformation getInstance()
        {
            if (api == null)
            {
                api = new AddPurchaseInformation();
                api.Closed += delegate { api = null; };
            }
            return api;
        }

        public void showWindow()
        {
            if (api.WindowState == WindowState.Minimized)
                api.WindowState = WindowState.Normal;

            api.Show();
            api.Focus();
        }
        
        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string information = Information.Text;
            bool success;

            if (information.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }

            success = PurchaseInformationController.addPurchaseInformation(information);
            if (!success)
                MessageBox.Show("Fail to add purchase information");

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
