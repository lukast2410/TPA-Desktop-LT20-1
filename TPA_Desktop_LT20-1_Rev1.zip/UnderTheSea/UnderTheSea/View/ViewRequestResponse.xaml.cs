﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewRequestResponse.xaml
    /// </summary>
    public partial class ViewRequestResponse : Window
    {
        private static ViewRequestResponse vrr = null;

        private ViewRequestResponse()
        {
            InitializeComponent();
        }

        public static ViewRequestResponse getInstance()
        {
            if (vrr == null)
            {
                vrr = new ViewRequestResponse();
                vrr.Closed += delegate { vrr = null; };
            }
            return vrr;
        }

        public void showWindow()
        {
            if (vrr.WindowState == WindowState.Minimized)
                vrr.WindowState = WindowState.Normal;

            vrr.Show();
            vrr.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewHRDRequestData.Items.Clear();

            List<HRDRequest> hrdr = HRDRequestController.getAllHRDRequest();

            foreach (HRDRequest p in hrdr)
            {
                ViewHRDRequestData.Items.Add(p);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
