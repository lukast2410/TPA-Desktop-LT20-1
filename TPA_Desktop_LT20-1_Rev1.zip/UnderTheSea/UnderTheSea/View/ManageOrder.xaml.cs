﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageOrder.xaml
    /// </summary>
    public partial class ManageOrder : Window
    {
        private static ManageOrder mo = null;

        private ManageOrder()
        {
            InitializeComponent();
        }

        public static ManageOrder getInstance()
        {
            if (mo == null)
            {
                mo = new ManageOrder();
                mo.Closed += delegate { mo = null; };
            }
            return mo;
        }

        public void showWindow()
        {
            if (mo.WindowState == WindowState.Minimized)
                mo.WindowState = WindowState.Normal;

            mo.Show();
            mo.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ListOrderDetail.Items.Clear();

            List<OrderDetail> od = OrderController.getAllOrderDetail();

            foreach (OrderDetail o in od)
            {
                ListOrderDetail.Items.Add(o);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Update_Order_Btn_Click(object sender, RoutedEventArgs e)
        {
            UpdateOrder uo = UpdateOrder.getInstance();
            uo.showWindow();
        }

        private void Add_Order_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddNewOrder ano = AddNewOrder.getInstance();
            ano.showWindow();
        }
    }
}
