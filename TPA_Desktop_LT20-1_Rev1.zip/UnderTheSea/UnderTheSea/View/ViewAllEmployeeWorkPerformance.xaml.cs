﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllEmployeeWorkPerformance.xaml
    /// </summary>
    public partial class ViewAllEmployeeWorkPerformance : Window
    {
        private static ViewAllEmployeeWorkPerformance vaewp = null;

        private ViewAllEmployeeWorkPerformance()
        {
            InitializeComponent();
        }

        public static ViewAllEmployeeWorkPerformance getInstance()
        {
            if (vaewp == null)
            {
                vaewp = new ViewAllEmployeeWorkPerformance();
                vaewp.Closed += delegate { vaewp = null; };
            }
            return vaewp;
        }

        public void showWindow()
        {
            if (vaewp.WindowState == WindowState.Minimized)
                vaewp.WindowState = WindowState.Normal;

            vaewp.Show();
            vaewp.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewEmployeeWorkPerformance.Items.Clear();

            List<WorkPerformance> workPerformance = WorkPerformanceController.getAllWorkPerformance();

            foreach (WorkPerformance wp in workPerformance)
            {
                ViewEmployeeWorkPerformance.Items.Add(wp);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
