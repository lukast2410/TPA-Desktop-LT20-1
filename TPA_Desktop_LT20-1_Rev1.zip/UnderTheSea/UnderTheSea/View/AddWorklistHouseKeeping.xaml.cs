﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddWorklistHouseKeeping.xaml
    /// </summary>
    public partial class AddWorklistHouseKeeping : Window
    {
        private static AddWorklistHouseKeeping awhk = null;

        private AddWorklistHouseKeeping()
        {
            InitializeComponent();
        }

        public static AddWorklistHouseKeeping getInstance()
        {
            if (awhk == null)
            {
                awhk = new AddWorklistHouseKeeping();
                awhk.Closed += delegate { awhk = null; };
            }
            return awhk;
        }

        public void showWindow()
        {
            if (awhk.WindowState == WindowState.Minimized)
                awhk.WindowState = WindowState.Normal;

            awhk.Show();
            awhk.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string roomNumberText = RoomNumber.Text;
            int roomNumber;
            bool success = int.TryParse(roomNumberText, out roomNumber);
            string detail = Detail.Text;
            DateTime date = Date.DisplayDate;

            if (!success)
            {
                MessageBox.Show("Room Number must be number");
                return;
            }
            else if (detail.Length == 0 || Date.SelectedDate == null)
            {
                MessageBox.Show("Form are not complete");
                return;
            }

            success = WorklistHouseKeepingController.addWorklistHouseKeeping(roomNumber, detail, date);
            if (!success)
                MessageBox.Show("Room Number not valid");
            
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
        
    }
}
