﻿using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for GenerateTickets.xaml
    /// </summary>
    public partial class GenerateTickets : Window
    {
        private static GenerateTickets gt = null;

        private GenerateTickets()
        {
            InitializeComponent();
            Date.Text = DateTime.Today.DayOfWeek.ToString() + ", " + DateTime.Today.Date.ToString("dd/MM/yyyy");
        }

        public static GenerateTickets getInstance()
        {
            if (gt == null)
            {
                gt = new GenerateTickets();
                gt.Closed += delegate { gt = null; };
            }

            return gt;
        }

        public void showWindow()
        {
            if (gt.WindowState == WindowState.Minimized)
                gt.WindowState = WindowState.Normal;

            gt.Focus();
            gt.Show();
        }

        private void Generate_Ticket_Btn_Click(object sender, RoutedEventArgs e)
        {
            Ticket t = TicketController.generateTicket();

            QRCodeGenerator qrCodeGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrCodeGenerator.CreateQrCode(t.Code.ToString(), QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            TicketId.Text = "Ticket ID: " + t.Code.ToString();

            QRCode.Source = bitmapConvertToImageSource(qrCodeImage);
        }

        private ImageSource bitmapConvertToImageSource(Bitmap bitmap)
        {
            using(MemoryStream memory = new MemoryStream())
            {
                bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Bmp);
                memory.Position = 0;
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memory;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();

                return bitmapImage;
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
