﻿using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for CheckTicket.xaml
    /// </summary>
    public partial class CheckTicket : Window
    {
        private static CheckTicket ct = null;

        private CheckTicket()
        {
            InitializeComponent();
            Date.Text = DateTime.Today.DayOfWeek.ToString() + ", " + DateTime.Today.Date.ToString("dd/MM/yyyy");
        }

        public static CheckTicket getInstance()
        {
            if (ct == null)
            {
                ct = new CheckTicket();
                ct.Closed += delegate { ct = null; };
            }

            return ct;
        }

        public void showWindow()
        {
            if (ct.WindowState == WindowState.Minimized)
                ct.WindowState = WindowState.Normal;

            ct.Focus();
            ct.Show();
        }

        private void Check_Ticket_Btn_Click(object sender, RoutedEventArgs e)
        {
            string ticketId = inputTicketId.Text;
            int code;
            bool success = int.TryParse(ticketId, out code);

            if (!success){
                MessageBox.Show("Invalid Id");
                return;
            }

            Ticket t = TicketController.scanTicket(code);

            if(t == null){
                MessageBox.Show("Ticket Not Valid");
                return;
            }

            QRCodeGenerator qrCodeGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrCodeGenerator.CreateQrCode(t.Code.ToString(), QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            QRCode.Source = bitmapConvertToImageSource(qrCodeImage);
        }

        private ImageSource bitmapConvertToImageSource(Bitmap bitmap)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Bmp);
                memory.Position = 0;
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memory;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();

                return bitmapImage;
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
