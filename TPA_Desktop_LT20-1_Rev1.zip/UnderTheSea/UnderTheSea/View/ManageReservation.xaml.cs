﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageReservation.xaml
    /// </summary>
    public partial class ManageReservation : Window
    {
        private static ManageReservation mr = null;

        private ManageReservation()
        {
            InitializeComponent();
        }

        public static ManageReservation getInstance()
        {
            if (mr == null)
            {
                mr = new ManageReservation();
                mr.Closed += delegate { mr = null; };
            }
            return mr;
        }

        public void showWindow()
        {
            if (mr.WindowState == WindowState.Minimized)
                mr.WindowState = WindowState.Normal;

            mr.Show();
            mr.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllReservationData.Items.Clear();

            List<Reservation> reserv = ReservationController.getAllReservation();

            foreach (Reservation r in reserv)
            {
                ViewAllReservationData.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Remove_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = RemoveId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            ReservationController.removeReservation(id);

            refreshData();
        }

        private void Add_Update_Reservation_Data_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddUpdateReservation aur = AddUpdateReservation.getInstance();
            aur.showWindow();
        }
    }
}
