﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewPurchaseRequest.xaml
    /// </summary>
    public partial class ViewPurchaseRequest : Window
    {
        private static ViewPurchaseRequest vpr = null;

        private ViewPurchaseRequest()
        {
            InitializeComponent();
        }

        public static ViewPurchaseRequest getInstance()
        {
            if (vpr == null)
            {
                vpr = new ViewPurchaseRequest();
                vpr.Closed += delegate { vpr = null; };
            }
            return vpr;
        }

        public void showWindow()
        {
            if (vpr.WindowState == WindowState.Minimized)
                vpr.WindowState = WindowState.Normal;

            vpr.Show();
            vpr.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewPurchaseRequestData.Items.Clear();

            List<PurchaseRequest> pr = PurchaseRequestController.getAllPurchaseRequest();

            foreach (PurchaseRequest p in pr)
            {
                ViewPurchaseRequestData.Items.Add(p);
            }
        }

        private void Accept_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            success = PurchaseRequestController.updatePurchaseRequestStatus(id, "Accepted");

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Reject_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            success = PurchaseRequestController.updatePurchaseRequestStatus(id, "Rejected");

            if (!success)
                MessageBox.Show("Id not found");

            refreshData();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
