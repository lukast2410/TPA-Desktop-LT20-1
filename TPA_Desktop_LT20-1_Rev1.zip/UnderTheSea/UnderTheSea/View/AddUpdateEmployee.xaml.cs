﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateEmployee.xaml
    /// </summary>
    public partial class AddUpdateEmployee : Window
    {
        private static AddUpdateEmployee aue = null;

        private AddUpdateEmployee()
        {
            InitializeComponent();
            loadComboBoxItem();
        }

        public static AddUpdateEmployee getInstance()
        {
            if (aue == null)
            {
                aue = new AddUpdateEmployee();
                aue.Closed += delegate { aue = null; };
            }
            return aue;
        }

        public void showWindow()
        {
            if (aue.WindowState == WindowState.Minimized)
                aue.WindowState = WindowState.Normal;

            aue.Show();
            aue.Focus();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string name = Name.Text;
            string email = Email.Text;
            string password = Password.Text;
            DateTime dob = DOB.DisplayDate;
            string gender = "";
            string phone = Phone.Text;
            int roleId = int.Parse(((ComboBoxItem)RoleComboBox.SelectedItem).Tag.ToString());
            string status = Status.Text;
            string salaryText = Salary.Text;
            int salary;
            bool success = int.TryParse(salaryText, out salary);

            if (Male.IsChecked == true)
                gender = "Male";
            else if (Female.IsChecked == true)
                gender = "Female";

            if (name.Length == 0 || email.Length == 0 || password.Length == 0 || DOB.SelectedDate == null || gender.Length == 0 ||
                phone.Length == 0 || roleId == 0 || status.Length == 0 || salaryText.Length == 0){
                MessageBox.Show("Form are not complete");
                return;
            }else if (email.IndexOf('@') == -1 || email.IndexOf('@') != email.IndexOf('@') || !email.EndsWith(".com") || 
                email.IndexOf('@') == (email.Length - 5) || email.IndexOf('@') == 0){
                MessageBox.Show("Wrong email format");
                return;
            }else if(password.Length < 6){
                MessageBox.Show("Password Length minimum 6 characters");
                return;
            }else if (!phone.All(char.IsDigit)){
                MessageBox.Show("Phone must be numeric");
                return;
            }else if(success == false){
                MessageBox.Show("Salary must be numeric");
                return;
            }
            
            success = EmployeeController.addEmployee(name, email, password, dob, gender, phone, roleId, status, salary);
            if (!success)
                MessageBox.Show("Email already exist");

            refreshData();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string employeeId = Id.Text;
            int id;
            bool parseId = int.TryParse(employeeId, out id);
            string name = Name.Text;
            string email = Email.Text;
            string password = Password.Text;
            DateTime dob = DOB.DisplayDate;
            string gender = "";
            string phone = Phone.Text;
            int roleId = int.Parse(((ComboBoxItem)RoleComboBox.SelectedItem).Tag.ToString());
            string status = Status.Text;
            string salaryText = Salary.Text;
            int salary;
            bool success = int.TryParse(salaryText, out salary);

            if (Male.IsChecked == true)
                gender = "Male";
            else if (Female.IsChecked == true)
                gender = "Female";

            if (employeeId.Length == 0 || name.Length == 0 || email.Length == 0 || password.Length == 0 || DOB.SelectedDate == null || gender.Length == 0 ||
                phone.Length == 0 || roleId == 0 || status.Length == 0 || salaryText.Length == 0) {
                MessageBox.Show("Please input all the form");
                return;
            } else if (!parseId){
                MessageBox.Show("Id must be number");
                return;
            } else if (email.IndexOf('@') == -1 || email.IndexOf('@') != email.IndexOf('@') || !email.EndsWith(".com") ||
            email.IndexOf('@') == (email.Length - 5) || email.IndexOf('@') == 0) {
                MessageBox.Show("Wrong email format");
                return;
            } else if (password.Length < 6) {
                MessageBox.Show("Password Length minimum 6 characters");
                return;
            } else if (!phone.All(char.IsDigit)) {
                MessageBox.Show("Phone must be numeric");
                return;
            } else if (success == false) {
                MessageBox.Show("Salary must be numeric");
                return;
            }

            success = EmployeeController.updateEmployee(id, name, email, password, dob, gender, phone, roleId, status, salary);
            if (!success)
                MessageBox.Show("Email already exist");

            refreshData();
        }

        private void refreshData()
        {
            ManageEmployeeData med = ManageEmployeeData.getInstance();
            med.viewAllEmployeeData();
        }

        private void loadComboBoxItem()
        {
            ComboBoxItem item = new ComboBoxItem();
            item.Content = "Select Role";
            item.Tag = 0;
            RoleComboBox.Items.Add(item);

            foreach(Role role in RoleController.getAllRole())
            {
                item = new ComboBoxItem();
                item.Content = role.RoleName;
                item.Tag = role.Id;
                RoleComboBox.Items.Add(item);
            }
        }
        
    }
}
