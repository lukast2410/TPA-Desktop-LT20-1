﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for Charge.xaml
    /// </summary>
    public partial class Charge : Window
    {
        private static Charge c = null;

        private Charge()
        {
            InitializeComponent();
        }

        public static Charge getInstance()
        {
            if (c == null)
            {
                c = new Charge();
                c.Closed += delegate { c = null; };
            }
            return c;
        }

        public void showWindow()
        {
            if (c.WindowState == WindowState.Minimized)
                c.WindowState = WindowState.Normal;

            c.Show();
            c.Focus();
        }

        private void Charge_Btn_Click(object sender, RoutedEventArgs e)
        {
            string visitorIdText = VisitorId.Text;
            int visitorId = 0;
            string totalAmountText = TotalAmount.Text;
            int price = 0;
            string information = Information.Text;

            bool success = int.TryParse(visitorIdText, out visitorId);
            if (success)
                success = int.TryParse(totalAmountText, out price);

            if (!success){
                MessageBox.Show("Wrong input!");
                return;
            }

            success = ChargeController.charge(visitorId, price, information);
            if (!success)
                MessageBox.Show("Data Not Valid");
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
