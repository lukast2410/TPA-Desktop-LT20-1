﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageVisitorData.xaml
    /// </summary>
    public partial class ManageVisitorData : Window
    {
        private static ManageVisitorData mvd = null;

        private ManageVisitorData()
        {
            InitializeComponent();
        }

        public static ManageVisitorData getInstance()
        {
            if (mvd == null)
            {
                mvd = new ManageVisitorData();
                mvd.Closed += delegate { mvd = null; };
            }
            return mvd;
        }

        public void showWindow()
        {
            if (mvd.WindowState == WindowState.Minimized)
                mvd.WindowState = WindowState.Normal;

            mvd.Show();
            mvd.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllVisitorData.Items.Clear();

            List<VisitorData> visitor = VisitorDataController.getAllVisitorData();

            foreach (VisitorData v in visitor)
            {
                ViewAllVisitorData.Items.Add(v);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Remove_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = RemoveId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            VisitorDataController.removeVisitorData(id);

            refreshData();
        }

        private void Add_Update_Visitor_Data_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddUpdateVisitorData auvd = AddUpdateVisitorData.getInstance();
            auvd.showWindow();
        }
    }
}
