﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewInbox.xaml
    /// </summary>
    public partial class ViewInbox : Window
    {
        private static ViewInbox vi = null;

        private ViewInbox()
        {
            InitializeComponent();
        }

        public static ViewInbox getInstance()
        {
            if (vi == null)
            {
                vi = new ViewInbox();
                vi.Closed += delegate { vi = null; };
            }
            return vi;
        }

        public void showWindow()
        {
            if (vi.WindowState == WindowState.Minimized)
                vi.WindowState = WindowState.Normal;

            vi.Show();
            vi.Focus();
            refreshData();
        }

        private void refreshData()
        {
            ViewInboxes.Items.Clear();

            List<Inbox> inboxes = InboxController.getRoleInbox();

            foreach(Inbox ibx in inboxes)
            {
                ViewInboxes.Items.Add(ibx);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void View_Detail_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success){
                MessageBox.Show("Id must be number");
                return;
            }

            Inbox ibx = InboxController.getOneInbox(id);
            if(ibx == null){
                MessageBox.Show("Not Found");
                return;
            }

            ViewInboxDetail vid = ViewInboxDetail.getInstance();
            vid.showWindow(ibx);
        }
    }
}
