﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllWorklistHouseKeeping.xaml
    /// </summary>
    public partial class ViewAllWorklistHouseKeeping : Window
    {
        private static ViewAllWorklistHouseKeeping vawhk = null;

        private ViewAllWorklistHouseKeeping()
        {
            InitializeComponent();
        }

        public static ViewAllWorklistHouseKeeping getInstance()
        {
            if (vawhk == null)
            {
                vawhk = new ViewAllWorklistHouseKeeping();
                vawhk.Closed += delegate { vawhk = null; };
            }
            return vawhk;
        }

        public void showWindow()
        {
            if (vawhk.WindowState == WindowState.Minimized)
                vawhk.WindowState = WindowState.Normal;

            vawhk.Show();
            vawhk.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllWorklist.Items.Clear();

            List<WorklistHouseKeeping> pi = WorklistHouseKeepingController.getAllWorklistHouseKeeping();

            foreach (WorklistHouseKeeping p in pi)
            {
                ViewAllWorklist.Items.Add(p);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
