﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AddUpdateWorkPerformance.xaml
    /// </summary>
    public partial class AddUpdateWorkPerformance : Window
    {
        private static AddUpdateWorkPerformance auwp = null;

        private AddUpdateWorkPerformance()
        {
            InitializeComponent();
        }

        public static AddUpdateWorkPerformance getInstance()
        {
            if (auwp == null)
            {
                auwp = new AddUpdateWorkPerformance();
                auwp.Closed += delegate { auwp = null; };
            }
            return auwp;
        }

        public void showWindow()
        {
            if (auwp.WindowState == WindowState.Minimized)
                auwp.WindowState = WindowState.Normal;

            auwp.Show();
            auwp.Focus();
        }

        private void Update_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = Id.Text;
            int id;
            bool parseId = int.TryParse(inputId, out id); 
            string employeeIdText = EmployeeId.Text;
            int employeeId;
            bool success = int.TryParse(employeeIdText, out employeeId);
            string detail = Detail.Text;

            if (employeeIdText.Length == 0 || detail.Length == 0) {
                MessageBox.Show("The data is not complete");
                return;
            } else if (!parseId) {
                MessageBox.Show("Id must be number");
                return;
            } else if (!success) {
                MessageBox.Show("EmployeeId must be number");
                return;
            }

            success = WorkPerformanceController.updateWorkPerformance(id, employeeId, detail);

            if (!success)
                MessageBox.Show("Work Performance for this employee already exist");

            refreshData();
        }

        private void Add_Btn_Click(object sender, RoutedEventArgs e)
        {
            string employeeIdText = EmployeeId.Text;
            int employeeId;
            bool success = int.TryParse(employeeIdText, out employeeId);
            string detail = Detail.Text;

            if (employeeIdText.Length == 0 || detail.Length == 0){
                MessageBox.Show("The data is not complete");
                return;
            }else if (!success){
                MessageBox.Show("EmployeeId must be number");
                return;
            }

            success = WorkPerformanceController.addWorkPerformance(employeeId, detail);
            if (!success)
                MessageBox.Show("Work Performance for this employee already exist");

            refreshData();
        }

        private void refreshData()
        {
            ManageEmployeeWorkPerformance mewp = ManageEmployeeWorkPerformance.getInstance();
            mewp.refreshData();
        }
    }
}
