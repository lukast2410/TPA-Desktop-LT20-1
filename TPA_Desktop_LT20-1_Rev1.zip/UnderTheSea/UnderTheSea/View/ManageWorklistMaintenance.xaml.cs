﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ManageWorklistMaintenance.xaml
    /// </summary>
    public partial class ManageWorklistMaintenance : Window
    {
        private static ManageWorklistMaintenance mwm = null;

        private ManageWorklistMaintenance()
        {
            InitializeComponent();
        }

        public static ManageWorklistMaintenance getInstance()
        {
            if (mwm == null)
            {
                mwm = new ManageWorklistMaintenance();
                mwm.Closed += delegate { mwm = null; };
            }
            return mwm;
        }

        public void showWindow()
        {
            if (mwm.WindowState == WindowState.Minimized)
                mwm.WindowState = WindowState.Normal;

            mwm.Show();
            mwm.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllWorklistMaintenance.Items.Clear();

            List<WorklistMaintenance> wm = WorklistMaintenanceController.getAllWorklistMaintenance();

            foreach (WorklistMaintenance w in wm)
            {
                ViewAllWorklistMaintenance.Items.Add(w);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Remove_Btn_Click(object sender, RoutedEventArgs e)
        {
            string inputId = RemoveId.Text;
            int id;
            bool success = int.TryParse(inputId, out id);

            if (!success)
            {
                MessageBox.Show("Id must be number");
                return;
            }

            AdvertisementController.removeAdvertisement(id);

            refreshData();
        }

        private void Add_Update_Worklist_Maintenance_Btn_Click(object sender, RoutedEventArgs e)
        {
            AddUpdateWorklistMaintenance auwm = AddUpdateWorklistMaintenance.getInstance();
            auwm.showWindow();
        }
    }
}
