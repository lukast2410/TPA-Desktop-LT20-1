﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RequestPurchase.xaml
    /// </summary>
    public partial class RequestPurchase : Window
    {
        private static RequestPurchase rp = null;

        private RequestPurchase()
        {
            InitializeComponent();
        }

        public static RequestPurchase getInstance()
        {
            if (rp == null)
            {
                rp = new RequestPurchase();
                rp.Closed += delegate { rp = null; };
            }
            return rp;
        }

        public void showWindow()
        {
            if (rp.WindowState == WindowState.Minimized)
                rp.WindowState = WindowState.Normal;

            rp.Show();
            rp.Focus();
        }

        private void Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            string detail = Detail.Text;
            string information = Information.Text;
            int totalAmount;
            bool success;

            if (detail.Length == 0)
            {
                MessageBox.Show("Detail must be filled");
                return;
            }

            success = PurchaseRequestController.requestPurchase(detail, information);
            if (!success)
                MessageBox.Show("Fail to request");

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
