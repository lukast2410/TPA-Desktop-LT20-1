﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RequestCheckRoom.xaml
    /// </summary>
    public partial class RequestCheckRoom : Window
    {
        private static RequestCheckRoom rcr = null;

        private RequestCheckRoom()
        {
            InitializeComponent();
        }

        public static RequestCheckRoom getInstance()
        {
            if (rcr == null)
            {
                rcr = new RequestCheckRoom();
                rcr.Closed += delegate { rcr = null; };
            }
            return rcr;
        }

        public void showWindow()
        {
            if (rcr.WindowState == WindowState.Minimized)
                rcr.WindowState = WindowState.Normal;

            rcr.Show();
            rcr.Focus();
        }

        private void Request_Btn_Click(object sender, RoutedEventArgs e)
        {
            string roomNumberText = RoomNumber.Text;
            int roomNumber;
            bool success = int.TryParse(roomNumberText, out roomNumber);

            if (!success)
            {
                MessageBox.Show("Room Number must be number");
                return;
            }

            success = CheckRoomRequestController.requestCheckRoom(roomNumber);

            if (!success){
                MessageBox.Show("Room Number invalid");
                return;
            }

            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
