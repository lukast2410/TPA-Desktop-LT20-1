﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewConstructionRequest.xaml
    /// </summary>
    public partial class ViewConstructionRequest : Window
    {
        private static ViewConstructionRequest vcr = null;

        private ViewConstructionRequest()
        {
            InitializeComponent();
        }

        public static ViewConstructionRequest getInstance()
        {
            if (vcr == null)
            {
                vcr = new ViewConstructionRequest();
                vcr.Closed += delegate { vcr = null; };
            }
            return vcr;
        }

        public void showWindow()
        {
            if (vcr.WindowState == WindowState.Minimized)
                vcr.WindowState = WindowState.Normal;

            vcr.Show();
            vcr.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewAllConstructionRequest.Items.Clear();

            List<ConstructionRequest> cr = ConstructionRequestController.getAllConstructionRequest();

            foreach (ConstructionRequest c in cr)
            {
                ViewAllConstructionRequest.Items.Add(c);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
