﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Controller;
using UnderTheSea.Model;
using UnderTheSea.Singleton;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ViewAllRideAndAttraction.xaml
    /// </summary>
    public partial class ViewAllRideAndAttraction : Window
    {
        private static ViewAllRideAndAttraction varaa = null;

        private ViewAllRideAndAttraction()
        {
            InitializeComponent();
        }

        public static ViewAllRideAndAttraction getInstance()
        {
            if (varaa == null)
            {
                varaa = new ViewAllRideAndAttraction();
                varaa.Closed += delegate { varaa = null; };
            }
            return varaa;
        }

        public void showWindow()
        {
            if (varaa.WindowState == WindowState.Minimized)
                varaa.WindowState = WindowState.Normal;

            varaa.Show();
            varaa.Focus();
            refreshData();
        }

        public void refreshData()
        {
            ViewRideAndAttraction.Items.Clear();

            List<RideAndAttraction> raa = RideAndAttractionController.getAllRideAndAttraction();

            foreach (RideAndAttraction r in raa)
            {
                ViewRideAndAttraction.Items.Add(r);
            }
        }

        private void Home_Btn_Click(object sender, RoutedEventArgs e)
        {
            EmployeeSingleton.goToRoleHome();
            this.Close();
        }
    }
}
