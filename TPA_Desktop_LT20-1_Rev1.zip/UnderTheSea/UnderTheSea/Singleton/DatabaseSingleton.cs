﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Singleton
{
    class DatabaseSingleton
    {
        private static UnderTheSeaEntities dba = null;

        public static UnderTheSeaEntities getInstance()
        {
            if (dba == null)
                dba = new UnderTheSeaEntities();
            return dba;
        }
    }
}
