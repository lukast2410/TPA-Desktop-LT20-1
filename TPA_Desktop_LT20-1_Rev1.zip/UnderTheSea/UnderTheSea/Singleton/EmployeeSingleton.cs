﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;
using UnderTheSea.Repository;
using UnderTheSea.View;

namespace UnderTheSea.Singleton
{
    class EmployeeSingleton
    {
        private static Employee emp = null;

        public static Employee getEmployee(string email, string password)
        {
            if (emp == null)
                emp = EmployeeRepository.login(email, password);

            return emp;
        }

        public static Employee getEmployeeData()
        {
            return emp;
        }

        public static void destroy()
        {
            emp = null;
        }

        public static void goToRoleHome()
        {
            int roleId = emp.RoleId;
            if (roleId == 1)
            {
                //manager
                ManagerHomePage home = ManagerHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 2)
            {
                //hrd
                HRDHomePage home = HRDHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 3)
            {
                //finance
                FinanceHomePage home = FinanceHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 4)
            {
                //purchasing
                PurchaseHomePage home = PurchaseHomePage.getInstance();
                home.showWindow();

            }
            else if (roleId == 5)
            {
                //construction
                ConstructionHomePage home = ConstructionHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 6)
            {
                //Sales and marketing
                SalesHomePage home = SalesHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 7)
            {
                //Ride and attraction
                RideAndAttractionHomePage home = RideAndAttractionHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 8)
            {
                //Kitchen
                KitchenDivision home = KitchenDivision.getInstance();
                home.showWindow();
            }
            else if (roleId == 9)
            {
                //Dining Room
                DiningRoomDivision home = DiningRoomDivision.getInstance();
                home.showWindow();
            }
            else if (roleId == 10)
            {
                //Attraction
                AttractionHomePage home = AttractionHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 11)
            {
                //Maintenance
                MaintenanceHomePage home = MaintenanceHomePage.getInstance();
                home.showWindow();
            }
            else if (roleId == 12)
            {
                //Front Office
                FrontOfficeDivision home = FrontOfficeDivision.getInstance();
                home.showWindow();
            }
            else if (roleId == 13)
            {
                //House Keeping
                HouseKeepingDivision home = HouseKeepingDivision.getInstance();
                home.showWindow();
            }
        }
    }
}
